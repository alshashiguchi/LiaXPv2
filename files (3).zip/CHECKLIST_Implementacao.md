# LiaXP - Checklist de Implementação

## 📋 Progresso Geral

```
[░░░░░░░░░░] 0%  - Não iniciado
[████░░░░░░] 40% - Em progresso
[██████████] 100% - Concluído
```

---

## 🎯 Fase 1: Configuração Inicial (Crítica)

### Setup do Ambiente
- [ ] .NET 8 SDK instalado
- [ ] SQL Server rodando (local ou Azure)
- [ ] Git instalado
- [ ] IDE configurada (VS Code, Visual Studio, Rider)
- [ ] Repositório clonado: `git clone https://github.com/alshashiguchi/LiaXPv2.git`

### Banco de Dados
- [ ] Banco de dados `LiaXP` criado
- [ ] Script `00-init-database.sql` executado
- [ ] Script `01-create-users-table.sql` executado
- [ ] Script `02-create-sales-tables.sql` executado
- [ ] Script `03-create-chat-tables.sql` executado
- [ ] Script `04-create-reviews-tables.sql` executado
- [ ] Script `05-create-stored-procedures.sql` executado
- [ ] Usuário admin criado e senha hash gerado

### Configuração do Projeto
- [ ] `appsettings.json` configurado com connection string
- [ ] JWT SigningKey configurado (min 32 caracteres)
- [ ] Pacotes NuGet instalados
- [ ] Projeto compila sem erros: `dotnet build`

**Status Fase 1**: [░░░░░░░░░░] 0/13

---

## 🔐 Fase 2: Autenticação (CRÍTICA - /auth/token)

### Domain Layer
- [ ] `User.cs` entity criado em `Domain/Entities/`
- [ ] `UserRole` enum definido
- [ ] `IUserRepository.cs` interface criada em `Domain/Interfaces/`
- [ ] `IPasswordHasher.cs` interface criada
- [ ] `ITokenService.cs` interface criada

### Application Layer
- [ ] `LoginRequest.cs` DTO criado em `Application/DTOs/Auth/`
- [ ] `LoginResponse.cs` DTO criado
- [ ] `LoginUseCase.cs` criado em `Application/UseCases/Auth/`

### Infrastructure Layer
- [ ] `UserRepository.cs` implementado em `Infrastructure/Data/Repositories/`
- [ ] `PasswordHasher.cs` implementado em `Infrastructure/Services/`
- [ ] `JwtTokenService.cs` implementado em `Infrastructure/Services/`

### API Layer
- [ ] `AuthController.cs` criado em `Api/Controllers/`
- [ ] Método `POST /auth/token` implementado
- [ ] Dependency Injection configurado no `Program.cs`
- [ ] JWT Authentication configurado no `Program.cs`
- [ ] Swagger configurado com JWT Bearer

### Testes
- [ ] Endpoint `/auth/token` testado no Swagger
- [ ] Login com credenciais corretas retorna token
- [ ] Login com credenciais incorretas retorna 401
- [ ] Token pode ser decodificado em jwt.io
- [ ] Token contém claims esperados (sub, email, role, company_code)

**Status Fase 2**: [░░░░░░░░░░] 0/20

---

## 💬 Fase 3: Chat com IA (/chat)

### Domain Layer
- [ ] `ChatMessage.cs` entity criado
- [ ] `ChatIntent` enum definido
- [ ] `IChatRepository.cs` interface criada
- [ ] `IAIService.cs` interface criada

### Application Layer
- [ ] `ChatRequest.cs` DTO criado
- [ ] `ChatResponse.cs` DTO criado
- [ ] `ProcessChatUseCase.cs` implementado

### Infrastructure Layer
- [ ] `ChatRepository.cs` implementado
- [ ] `OpenAIService.cs` implementado
- [ ] OpenAI API Key configurado

### API Layer
- [ ] `ChatController.cs` criado
- [ ] Método `POST /chat` implementado
- [ ] Autorização configurada (require authentication)
- [ ] Dependency Injection configurado

### Testes
- [ ] Endpoint `/chat` testado com token válido
- [ ] Intent detection funcionando
- [ ] Resposta da IA relevante
- [ ] Histórico salvo no banco

**Status Fase 3**: [░░░░░░░░░░] 0/16

---

## 📊 Fase 4: Importação de Dados (/data/import/xlsx)

### Domain Layer
- [ ] `SalesData.cs` entity criado
- [ ] `GoalData.cs` entity criado
- [ ] `TeamMember.cs` entity criado
- [ ] `IExcelImportService.cs` interface criada

### Application Layer
- [ ] `ImportExcelUseCase.cs` implementado

### Infrastructure Layer
- [ ] `ExcelImportService.cs` implementado
- [ ] ClosedXML configurado
- [ ] Bulk insert otimizado

### API Layer
- [ ] `DataController.cs` criado
- [ ] Método `POST /data/import/xlsx` implementado
- [ ] Autorização configurada (Admin/Manager only)
- [ ] File upload configurado

### Testes
- [ ] Importação de arquivo válido funciona
- [ ] Dados aparecem no banco após importação
- [ ] Validação de formato de arquivo funciona
- [ ] Mensagens de erro claras

**Status Fase 4**: [░░░░░░░░░░] 0/14

---

## 📱 Fase 5: Webhook WhatsApp (/webhook/whatsapp)

### Application Layer
- [ ] `WhatsAppWebhookRequest.cs` DTOs criados

### Infrastructure Layer
- [ ] WhatsApp provider configurado (Twilio ou Meta)
- [ ] Verificação de webhook implementada

### API Layer
- [ ] `WebhookController.cs` criado
- [ ] Método `GET /webhook/whatsapp` implementado (verificação)
- [ ] Método `POST /webhook/whatsapp` implementado (receber mensagens)

### Configuração
- [ ] WhatsApp credentials configurados
- [ ] Webhook URL registrado no provedor
- [ ] Testes de recebimento de mensagens

**Status Fase 5**: [░░░░░░░░░░] 0/9

---

## ⏰ Fase 6: Cron Jobs (/cron/run-now)

### Domain Layer
- [ ] `ScheduledMessage.cs` entity criado

### Application Layer
- [ ] Lógica de geração de mensagens implementada

### API Layer
- [ ] `CronController.cs` criado
- [ ] Método `POST /cron/run-now` implementado
- [ ] Autorização configurada (Admin/Manager only)

### Testes
- [ ] Geração manual de mensagens funciona
- [ ] Mensagens criadas aparecem no banco
- [ ] Parâmetros (moment, send) funcionam corretamente

**Status Fase 6**: [░░░░░░░░░░] 0/8

---

## 📈 Fase 7: Insights (/insights)

### Domain Layer
- [ ] `Insight.cs` entity criado

### Application Layer
- [ ] `GetInsightsUseCase.cs` implementado

### Infrastructure Layer
- [ ] Queries SQL otimizadas
- [ ] Cache implementado (opcional)

### API Layer
- [ ] Endpoint `/insights` implementado
- [ ] Filtros funcionando (seller, date range, type)

### Testes
- [ ] Insights sendo gerados corretamente
- [ ] Performance aceitável (< 500ms)

**Status Fase 7**: [░░░░░░░░░░] 0/9

---

## ✏️ Fase 8: Human-in-the-Loop (/reviews/*)

### Domain Layer
- [ ] `MessageReview.cs` entity criado

### Application Layer
- [ ] `GetPendingReviewsUseCase.cs` implementado
- [ ] `ApproveReviewUseCase.cs` implementado
- [ ] `EditAndApproveReviewUseCase.cs` implementado

### Infrastructure Layer
- [ ] Workflow de aprovação implementado
- [ ] Integração com WhatsApp para envio

### API Layer
- [ ] `GET /reviews/pending` implementado
- [ ] `POST /reviews/{id}/approve` implementado
- [ ] `POST /reviews/{id}/edit-and-approve` implementado

### Testes
- [ ] Listagem de mensagens pendentes funciona
- [ ] Aprovação envia mensagem
- [ ] Edição persiste antes de enviar

**Status Fase 8**: [░░░░░░░░░░] 0/11

---

## 🧪 Fase 9: Testes e Qualidade

### Testes Unitários
- [ ] Testes para `LoginUseCase`
- [ ] Testes para `ProcessChatUseCase`
- [ ] Testes para `ImportExcelUseCase`
- [ ] Testes para `PasswordHasher`
- [ ] Testes para `JwtTokenService`

### Testes de Integração
- [ ] Teste end-to-end de login
- [ ] Teste end-to-end de chat
- [ ] Teste end-to-end de importação

### Qualidade de Código
- [ ] Code coverage > 70%
- [ ] Nenhum warning do compilador
- [ ] SonarQube scan (se disponível)

**Status Fase 9**: [░░░░░░░░░░] 0/11

---

## 🚀 Fase 10: Deploy e Monitoramento

### Configuração de Produção
- [ ] Connection string de produção configurada
- [ ] JWT key forte configurada
- [ ] Secrets management configurado (Azure Key Vault ou similar)
- [ ] HTTPS configurado
- [ ] CORS configurado corretamente

### Deploy
- [ ] Dockerfile criado
- [ ] Docker Compose configurado
- [ ] Deploy para Azure App Service
- [ ] Banco de dados de produção configurado

### Monitoramento
- [ ] Application Insights configurado
- [ ] Health checks implementados
- [ ] Logging estruturado (Serilog)
- [ ] Alertas configurados

### Segurança
- [ ] Rate limiting configurado
- [ ] Input validation em todos os endpoints
- [ ] OWASP Top 10 verificado
- [ ] Dependency scan (Snyk ou similar)

**Status Fase 10**: [░░░░░░░░░░] 0/16

---

## 📊 Dashboard de Progresso

```
┌─────────────────────────────────────────────────────┐
│                 PROGRESSO GERAL                     │
├─────────────────────────────────────────────────────┤
│ Fase 1: Configuração Inicial    [░░░░░░░░░░]  0%   │
│ Fase 2: Autenticação ⭐          [░░░░░░░░░░]  0%   │
│ Fase 3: Chat com IA ⭐           [░░░░░░░░░░]  0%   │
│ Fase 4: Importação de Dados ⭐   [░░░░░░░░░░]  0%   │
│ Fase 5: Webhook WhatsApp         [░░░░░░░░░░]  0%   │
│ Fase 6: Cron Jobs                [░░░░░░░░░░]  0%   │
│ Fase 7: Insights                 [░░░░░░░░░░]  0%   │
│ Fase 8: Human-in-the-Loop        [░░░░░░░░░░]  0%   │
│ Fase 9: Testes                   [░░░░░░░░░░]  0%   │
│ Fase 10: Deploy                  [░░░░░░░░░░]  0%   │
├─────────────────────────────────────────────────────┤
│ TOTAL:                           [░░░░░░░░░░]  0%   │
│                                  0/127 tarefas      │
└─────────────────────────────────────────────────────┘

⭐ = Fase Crítica
```

---

## 🎯 Prioridades Recomendadas

### Alta Prioridade (Esta Semana)
1. **Fase 1**: Configuração Inicial
2. **Fase 2**: Autenticação (/auth/token) - **BLOCKER**
3. **Fase 3**: Chat com IA
4. **Fase 4**: Importação de Dados

### Média Prioridade (Próximas 2 Semanas)
5. **Fase 5**: Webhook WhatsApp
6. **Fase 6**: Cron Jobs
7. **Fase 7**: Insights

### Baixa Prioridade (Mês Seguinte)
8. **Fase 8**: Human-in-the-Loop
9. **Fase 9**: Testes Completos
10. **Fase 10**: Deploy e Monitoramento

---

## 📝 Notas de Implementação

### Bloqueadores Identificados
- [ ] Nenhum bloqueador identificado

### Riscos
- [ ] Nenhum risco identificado

### Dependências Externas
- [ ] OpenAI API Key necessária para Fase 3
- [ ] WhatsApp Provider account para Fase 5
- [ ] Azure account para Fase 10 (deploy)

### Tempo Estimado
- **Fase 1**: 30 minutos
- **Fase 2**: 2 horas
- **Fase 3**: 2 horas
- **Fase 4**: 3 horas
- **Fase 5**: 2 horas
- **Fase 6**: 1 hora
- **Fase 7**: 2 horas
- **Fase 8**: 3 horas
- **Fase 9**: 4 horas
- **Fase 10**: 4 horas

**TOTAL ESTIMADO**: ~23 horas de desenvolvimento

---

## 🏁 Critérios de Conclusão

### Mínimo Viável (MVP)
- [x] Fase 1 completa
- [x] Fase 2 completa
- [x] Fase 4 completa
- [x] Pelo menos 1 endpoint de cada categoria funcionando

### Produção (Production Ready)
- [x] Todas as 10 fases completas
- [x] Testes com coverage > 70%
- [x] Deploy em ambiente de produção
- [x] Monitoramento ativo
- [x] Documentação completa

---

## 📅 Última Atualização

**Data**: 24 de Outubro de 2025  
**Versão**: 1.0.0  
**Responsável**: [Seu nome aqui]

---

## 💡 Dicas

1. **Não pule a Fase 1** - Uma configuração correta evita horas de debugging
2. **Comece pela Fase 2** - Sem autenticação, nenhum outro endpoint funcionará
3. **Teste incrementalmente** - Não implemente tudo de uma vez
4. **Use o Swagger** - Facilita muito os testes
5. **Commit frequentemente** - Pequenos commits são mais fáceis de revisar
6. **Leia a documentação** - Tudo está documentado nos arquivos .md

---

**Mantenha este checklist atualizado conforme progride!** ✅
