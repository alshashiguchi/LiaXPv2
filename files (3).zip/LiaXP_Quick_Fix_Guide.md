# LiaXP - Guia Rápido de Correção: Implementar /auth/token

## 🎯 Objetivo

Este guia fornece os **passos mínimos e essenciais** para adicionar o endpoint `/auth/token` faltante ao seu projeto LiaXPv2, seguindo as melhores práticas de .NET com DDD e Clean Architecture.

---

## ⚡ Implementação Rápida (30 minutos)

### Passo 1: Adicionar Pacotes NuGet (2 min)

```bash
cd src/LiaXP.Api

dotnet add package Microsoft.AspNetCore.Authentication.JwtBearer --version 8.0.0
dotnet add package System.IdentityModel.Tokens.Jwt --version 7.0.3

cd ../LiaXP.Infrastructure
dotnet add package Microsoft.Data.SqlClient --version 5.1.5
dotnet add package Dapper --version 2.1.24
```

---

### Passo 2: Criar Entidade User no Domain (3 min)

**Arquivo:** `src/LiaXP.Domain/Entities/User.cs`

```csharp
namespace LiaXP.Domain.Entities;

public class User
{
    public Guid Id { get; set; }
    public string CompanyCode { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public UserRole Role { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? LastLoginAt { get; set; }
}

public enum UserRole
{
    Admin = 1,
    Manager = 2,
    Seller = 3
}
```

---

### Passo 3: Criar Interfaces no Domain (3 min)

**Arquivo:** `src/LiaXP.Domain/Interfaces/IUserRepository.cs`

```csharp
namespace LiaXP.Domain.Interfaces;

public interface IUserRepository
{
    Task<User?> GetByEmailAsync(string email, string companyCode);
    Task UpdateLastLoginAsync(Guid userId);
}
```

**Arquivo:** `src/LiaXP.Domain/Interfaces/IPasswordHasher.cs`

```csharp
namespace LiaXP.Domain.Interfaces;

public interface IPasswordHasher
{
    string HashPassword(string password);
    bool VerifyPassword(string password, string passwordHash);
}
```

**Arquivo:** `src/LiaXP.Domain/Interfaces/ITokenService.cs`

```csharp
namespace LiaXP.Domain.Interfaces;

public interface ITokenService
{
    string GenerateToken(User user);
}
```

---

### Passo 4: Implementar Repositório na Infrastructure (5 min)

**Arquivo:** `src/LiaXP.Infrastructure/Repositories/UserRepository.cs`

```csharp
using Dapper;
using LiaXP.Domain.Entities;
using LiaXP.Domain.Interfaces;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace LiaXP.Infrastructure.Repositories;

public class UserRepository : IUserRepository
{
    private readonly string _connectionString;

    public UserRepository(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("Connection string not found");
    }

    public async Task<User?> GetByEmailAsync(string email, string companyCode)
    {
        using var connection = new SqlConnection(_connectionString);
        
        const string sql = @"
            SELECT Id, CompanyCode, Email, PasswordHash, FullName, Role, IsActive, CreatedAt, LastLoginAt
            FROM Users
            WHERE Email = @Email AND CompanyCode = @CompanyCode AND IsActive = 1";

        return await connection.QueryFirstOrDefaultAsync<User>(sql, new { Email = email, CompanyCode = companyCode });
    }

    public async Task UpdateLastLoginAsync(Guid userId)
    {
        using var connection = new SqlConnection(_connectionString);
        
        const string sql = "UPDATE Users SET LastLoginAt = GETUTCDATE() WHERE Id = @UserId";
        
        await connection.ExecuteAsync(sql, new { UserId = userId });
    }
}
```

---

### Passo 5: Implementar Serviços na Infrastructure (7 min)

**Arquivo:** `src/LiaXP.Infrastructure/Services/PasswordHasher.cs`

```csharp
using LiaXP.Domain.Interfaces;
using System.Security.Cryptography;
using System.Text;

namespace LiaXP.Infrastructure.Services;

public class PasswordHasher : IPasswordHasher
{
    public string HashPassword(string password)
    {
        using var sha256 = SHA256.Create();
        var saltedPassword = password + "LiaXP_Salt_Key"; // Use uma chave fixa ou configurável
        var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(saltedPassword));
        return Convert.ToBase64String(bytes);
    }

    public bool VerifyPassword(string password, string passwordHash)
    {
        var computedHash = HashPassword(password);
        return computedHash == passwordHash;
    }
}
```

**Arquivo:** `src/LiaXP.Infrastructure/Services/JwtTokenService.cs`

```csharp
using LiaXP.Domain.Entities;
using LiaXP.Domain.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace LiaXP.Infrastructure.Services;

public class JwtTokenService : ITokenService
{
    private readonly string _signingKey;
    private readonly string _issuer;
    private readonly string _audience;

    public JwtTokenService(IConfiguration configuration)
    {
        _signingKey = configuration["Jwt:SigningKey"] ?? throw new InvalidOperationException("JWT SigningKey not configured");
        _issuer = configuration["Jwt:Issuer"] ?? "LiaXP";
        _audience = configuration["Jwt:Audience"] ?? "LiaXP-Api";
    }

    public string GenerateToken(User user)
    {
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, user.Email),
            new Claim(JwtRegisteredClaimNames.Name, user.FullName),
            new Claim(ClaimTypes.Role, user.Role.ToString()),
            new Claim("company_code", user.CompanyCode),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_signingKey));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: _issuer,
            audience: _audience,
            claims: claims,
            expires: DateTime.UtcNow.AddHours(1),
            signingCredentials: credentials
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
```

---

### Passo 6: Criar DTOs na Application (3 min)

**Arquivo:** `src/LiaXP.Application/DTOs/Auth/LoginRequest.cs`

```csharp
namespace LiaXP.Application.DTOs.Auth;

public class LoginRequest
{
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string CompanyCode { get; set; } = string.Empty;
}
```

**Arquivo:** `src/LiaXP.Application/DTOs/Auth/LoginResponse.cs`

```csharp
namespace LiaXP.Application.DTOs.Auth;

public class LoginResponse
{
    public string AccessToken { get; set; } = string.Empty;
    public string TokenType { get; set; } = "Bearer";
    public int ExpiresIn { get; set; } = 3600;
    public UserInfo User { get; set; } = null!;
}

public class UserInfo
{
    public Guid Id { get; set; }
    public string Email { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string CompanyCode { get; set; } = string.Empty;
}
```

---

### Passo 7: Criar Controller na API (5 min)

**Arquivo:** `src/LiaXP.Api/Controllers/AuthController.cs`

```csharp
using LiaXP.Application.DTOs.Auth;
using LiaXP.Domain.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace LiaXP.Api.Controllers;

[ApiController]
[Route("auth")]
public class AuthController : ControllerBase
{
    private readonly IUserRepository _userRepository;
    private readonly IPasswordHasher _passwordHasher;
    private readonly ITokenService _tokenService;
    private readonly ILogger<AuthController> _logger;

    public AuthController(
        IUserRepository userRepository,
        IPasswordHasher passwordHasher,
        ITokenService tokenService,
        ILogger<AuthController> logger)
    {
        _userRepository = userRepository;
        _passwordHasher = passwordHasher;
        _tokenService = tokenService;
        _logger = logger;
    }

    [HttpPost("token")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        // Validar entrada
        if (string.IsNullOrWhiteSpace(request.Email) || 
            string.IsNullOrWhiteSpace(request.Password) ||
            string.IsNullOrWhiteSpace(request.CompanyCode))
        {
            return BadRequest(new { error = "Email, senha e código da empresa são obrigatórios" });
        }

        // Buscar usuário
        var user = await _userRepository.GetByEmailAsync(request.Email, request.CompanyCode);

        if (user == null)
        {
            _logger.LogWarning("Tentativa de login com credenciais inválidas: {Email}", request.Email);
            return Unauthorized(new { error = "Credenciais inválidas" });
        }

        // Verificar senha
        if (!_passwordHasher.VerifyPassword(request.Password, user.PasswordHash))
        {
            _logger.LogWarning("Senha incorreta para usuário: {Email}", request.Email);
            return Unauthorized(new { error = "Credenciais inválidas" });
        }

        // Atualizar último login
        await _userRepository.UpdateLastLoginAsync(user.Id);

        // Gerar token
        var token = _tokenService.GenerateToken(user);

        var response = new LoginResponse
        {
            AccessToken = token,
            User = new UserInfo
            {
                Id = user.Id,
                Email = user.Email,
                FullName = user.FullName,
                Role = user.Role.ToString(),
                CompanyCode = user.CompanyCode
            }
        };

        _logger.LogInformation("Login bem-sucedido para usuário: {Email}", request.Email);
        return Ok(response);
    }
}
```

---

### Passo 8: Configurar DI no Program.cs (5 min)

**Arquivo:** `src/LiaXP.Api/Program.cs`

```csharp
using LiaXP.Domain.Interfaces;
using LiaXP.Infrastructure.Repositories;
using LiaXP.Infrastructure.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Controllers
builder.Services.AddControllers();

// Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "LiaXP API", Version = "v1" });
    
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "JWT Authorization header. Example: \"Bearer {token}\"",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
            },
            Array.Empty<string>()
        }
    });
});

// JWT Authentication
var jwtKey = builder.Configuration["Jwt:SigningKey"] ?? throw new InvalidOperationException("JWT SigningKey não configurada");

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
            ClockSkew = TimeSpan.Zero
        };
    });

builder.Services.AddAuthorization();

// Dependency Injection
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IPasswordHasher, PasswordHasher>();
builder.Services.AddScoped<ITokenService, JwtTokenService>();

// CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
    });
});

var app = builder.Build();

// Middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("AllowAll");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Run();
```

---

### Passo 9: Configurar appsettings.json (2 min)

**Arquivo:** `src/LiaXP.Api/appsettings.json`

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost,1433;Database=LiaXP;User Id=sa;Password=YourPassword123;TrustServerCertificate=True"
  },
  "Jwt": {
    "SigningKey": "your-super-secret-key-must-be-32-chars-minimum",
    "Issuer": "LiaXP-Api",
    "Audience": "LiaXP-Client"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
```

---

### Passo 10: Criar Tabela e Usuário no Banco (3 min)

Execute este SQL no seu banco de dados:

```sql
USE LiaXP;
GO

-- Criar tabela Users
CREATE TABLE Users (
    Id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    CompanyCode NVARCHAR(50) NOT NULL,
    Email NVARCHAR(255) NOT NULL,
    PasswordHash NVARCHAR(500) NOT NULL,
    FullName NVARCHAR(255) NOT NULL,
    Role INT NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    LastLoginAt DATETIME2 NULL,
    CONSTRAINT UK_Users_Email_Company UNIQUE (Email, CompanyCode)
);

-- Inserir usuário admin
-- Senha: Admin@123
-- Hash gerado: j8S8F+3h0X0Y0hR1K9J3qg== (exemplo, use o PasswordHasher para gerar o real)
INSERT INTO Users (Id, CompanyCode, Email, PasswordHash, FullName, Role, IsActive)
VALUES (
    NEWID(),
    'DEMO',
    'admin@liaxp.com',
    'wH9nY8cXxK7fK6jL5mN3pQ==',  -- Substitua pelo hash correto
    'Administrador',
    1,
    1
);
```

**IMPORTANTE**: Para gerar o hash correto da senha, execute este código C#:

```csharp
var hasher = new PasswordHasher();
var hash = hasher.HashPassword("Admin@123");
Console.WriteLine($"Hash: {hash}");
// Use este hash no INSERT acima
```

---

## 🧪 Testando

```bash
# 1. Executar a aplicação
cd src/LiaXP.Api
dotnet run

# 2. Testar o endpoint
curl -X POST "http://localhost:5000/auth/token" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@liaxp.com",
    "password": "Admin@123",
    "companyCode": "DEMO"
  }'

# Resposta esperada:
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "tokenType": "Bearer",
  "expiresIn": 3600,
  "user": {
    "id": "guid-here",
    "email": "admin@liaxp.com",
    "fullName": "Administrador",
    "role": "Admin",
    "companyCode": "DEMO"
  }
}
```

---

## 🔐 Testando Endpoint Protegido

```bash
# Copie o token da resposta anterior

# Teste um endpoint protegido
curl -X GET "http://localhost:5000/data/status" \
  -H "Authorization: Bearer SEU_TOKEN_AQUI"
```

---

## 📋 Checklist de Verificação

- [ ] Pacotes NuGet instalados
- [ ] Entidade User criada
- [ ] Interfaces criadas
- [ ] Repositório implementado
- [ ] Serviços (PasswordHasher, JwtTokenService) implementados
- [ ] DTOs criados
- [ ] Controller criado
- [ ] DI configurado no Program.cs
- [ ] appsettings.json configurado
- [ ] Tabela Users criada no banco
- [ ] Usuário admin inserido
- [ ] Aplicação executa sem erros
- [ ] Endpoint /auth/token responde corretamente
- [ ] Token JWT é gerado corretamente

---

## 🐛 Troubleshooting

### Erro: "Connection string not found"
**Solução**: Verifique se `appsettings.json` tem a connection string correta.

### Erro: "JWT SigningKey não configurada"
**Solução**: Adicione a chave no `appsettings.json`:
```json
"Jwt": {
  "SigningKey": "sua-chave-com-minimo-32-caracteres-aqui"
}
```

### Erro: "Credenciais inválidas" mesmo com senha correta
**Solução**: O hash da senha no banco não está correto. Gere novamente:
```csharp
var hasher = new PasswordHasher();
var hash = hasher.HashPassword("Admin@123");
// Atualize no banco: UPDATE Users SET PasswordHash = 'hash-aqui' WHERE Email = 'admin@liaxp.com'
```

### Erro: "Cannot access a disposed object"
**Solução**: Verifique se está usando `using` statements ou registrando serviços como `Scoped`.

---

## 🚀 Próximos Passos

Após implementar `/auth/token`, você pode:

1. **Adicionar outros usuários**:
```sql
INSERT INTO Users (Id, CompanyCode, Email, PasswordHash, FullName, Role, IsActive)
VALUES (NEWID(), 'DEMO', 'gerente@liaxp.com', 'hash-aqui', 'Gerente', 2, 1);
```

2. **Proteger endpoints existentes**:
```csharp
[Authorize]  // Requer autenticação
[Authorize(Roles = "Admin,Manager")]  // Requer role específica
public class MyController : ControllerBase { }
```

3. **Implementar refresh tokens** para melhor segurança

4. **Adicionar rate limiting** para proteger contra ataques

---

## 📚 Recursos Adicionais

- [JWT.io](https://jwt.io) - Decodificar e testar tokens JWT
- [Postman](https://www.postman.com) - Ferramenta para testar APIs
- [.NET Authentication Docs](https://docs.microsoft.com/aspnet/core/security/authentication/)

---

## ✅ Implementação Completa!

Agora seu projeto tem:
- ✅ Autenticação JWT funcional
- ✅ Endpoint `/auth/token` implementado
- ✅ Arquitetura limpa (DDD + Clean Architecture)
- ✅ Segurança com hash de senha
- ✅ Pronto para adicionar os demais endpoints

**Tempo total estimado: ~30 minutos** 🎉
