# LiaXP - Scripts de Banco de Dados e Configuração (Parte 3)

## 🗄️ Scripts de Banco de Dados

### Script 1: Inicialização do Banco

```sql
-- scripts/00-init-database.sql
USE master;
GO

IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'LiaXP')
BEGIN
    CREATE DATABASE LiaXP;
    PRINT 'Database LiaXP criado com sucesso';
END
GO

USE LiaXP;
GO

PRINT 'Banco de dados LiaXP inicializado';
```

### Script 2: Tabela de Usuários

```sql
-- scripts/01-create-users-table.sql
USE LiaXP;
GO

-- Tabela de Usuários
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Users]'))
BEGIN
    CREATE TABLE [dbo].[Users] (
        [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        [CompanyCode] NVARCHAR(50) NOT NULL,
        [Email] NVARCHAR(255) NOT NULL,
        [PasswordHash] NVARCHAR(500) NOT NULL,
        [FullName] NVARCHAR(255) NOT NULL,
        [Role] INT NOT NULL, -- 1=Admin, 2=Manager, 3=Seller
        [IsActive] BIT NOT NULL DEFAULT 1,
        [CreatedAt] DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        [LastLoginAt] DATETIME2 NULL,
        [UpdatedAt] DATETIME2 NULL,
        
        CONSTRAINT [UK_Users_Email_Company] UNIQUE ([Email], [CompanyCode])
    );

    CREATE NONCLUSTERED INDEX [IX_Users_Email_Company] 
        ON [dbo].[Users] ([Email], [CompanyCode], [IsActive]);
    
    CREATE NONCLUSTERED INDEX [IX_Users_CompanyCode] 
        ON [dbo].[Users] ([CompanyCode]) WHERE [IsActive] = 1;

    PRINT 'Tabela Users criada com sucesso';
END
GO

-- Stored Procedure para criar hash de senha (exemplo usando HASHBYTES)
CREATE OR ALTER PROCEDURE [dbo].[sp_CreatePasswordHash]
    @Password NVARCHAR(255),
    @PasswordHash NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Gerar salt aleatório
    DECLARE @Salt UNIQUEIDENTIFIER = NEWID();
    DECLARE @SaltString NVARCHAR(36) = CAST(@Salt AS NVARCHAR(36));
    
    -- Concatenar senha com salt e gerar hash
    DECLARE @PasswordWithSalt NVARCHAR(500) = @Password + @SaltString;
    DECLARE @Hash VARBINARY(64) = HASHBYTES('SHA2_512', @PasswordWithSalt);
    
    -- Retornar salt + hash em Base64
    SET @PasswordHash = @SaltString + ':' + CAST('' AS XML).value('xs:base64Binary(xs:hexBinary(sql:variable("@Hash")))', 'NVARCHAR(500)');
END
GO

-- Inserir usuário administrador padrão
-- Senha padrão: Admin@123 (TROQUE EM PRODUÇÃO!)
DECLARE @AdminPasswordHash NVARCHAR(500);

IF NOT EXISTS (SELECT 1 FROM [dbo].[Users] WHERE Email = 'admin@liaxp.com' AND CompanyCode = 'DEMO')
BEGIN
    -- Para simplificar, use um hash fixo aqui
    -- Em produção, use o serviço de hash da aplicação
    SET @AdminPasswordHash = 'AQAAAAIAAYagAAAAEHD5Y8mE9SkD7xZvBxqK9Q=='; -- Placeholder
    
    INSERT INTO [dbo].[Users] 
        ([Id], [CompanyCode], [Email], [PasswordHash], [FullName], [Role], [IsActive], [CreatedAt])
    VALUES 
        (NEWID(), 'DEMO', 'admin@liaxp.com', @AdminPasswordHash, 'Administrador', 1, 1, GETUTCDATE()),
        (NEWID(), 'DEMO', 'gerente@liaxp.com', @AdminPasswordHash, 'Gerente', 2, 1, GETUTCDATE()),
        (NEWID(), 'DEMO', 'vendedor@liaxp.com', @AdminPasswordHash, 'Vendedor', 3, 1, GETUTCDATE());
    
    PRINT 'Usuários padrão criados com sucesso';
END
GO
```

### Script 3: Tabelas de Vendas e Metas

```sql
-- scripts/02-create-sales-tables.sql
USE LiaXP;
GO

-- Tabela de Dados de Vendas
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SalesData]'))
BEGIN
    CREATE TABLE [dbo].[SalesData] (
        [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        [CompanyCode] NVARCHAR(50) NOT NULL,
        [Date] DATE NOT NULL,
        [Store] NVARCHAR(255) NOT NULL,
        [SellerCode] NVARCHAR(50) NOT NULL,
        [SellerName] NVARCHAR(255) NOT NULL,
        [TotalValue] DECIMAL(18,2) NOT NULL,
        [ItemsQty] INT NOT NULL,
        [AvgTicket] DECIMAL(18,2) NOT NULL,
        [Category] NVARCHAR(100) NOT NULL,
        [ImportedAt] DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
        INDEX [IX_SalesData_Company_Date] ([CompanyCode], [Date] DESC),
        INDEX [IX_SalesData_Seller] ([CompanyCode], [SellerCode], [Date] DESC)
    );

    PRINT 'Tabela SalesData criada com sucesso';
END
GO

-- Tabela de Metas
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GoalsData]'))
BEGIN
    CREATE TABLE [dbo].[GoalsData] (
        [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        [CompanyCode] NVARCHAR(50) NOT NULL,
        [Month] NVARCHAR(7) NOT NULL, -- Formato: YYYY-MM
        [Store] NVARCHAR(255) NOT NULL,
        [SellerCode] NVARCHAR(50) NOT NULL,
        [TargetValue] DECIMAL(18,2) NOT NULL,
        [TargetTicket] DECIMAL(18,2) NOT NULL,
        [TargetConversion] NVARCHAR(10) NOT NULL, -- Ex: "15%"
        [ImportedAt] DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
        CONSTRAINT [UK_Goals_Company_Month_Seller] 
            UNIQUE ([CompanyCode], [Month], [SellerCode]),
        INDEX [IX_GoalsData_Company_Month] ([CompanyCode], [Month])
    );

    PRINT 'Tabela GoalsData criada com sucesso';
END
GO

-- Tabela de Equipe
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TeamMembers]'))
BEGIN
    CREATE TABLE [dbo].[TeamMembers] (
        [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        [CompanyCode] NVARCHAR(50) NOT NULL,
        [SellerCode] NVARCHAR(50) NOT NULL,
        [SellerName] NVARCHAR(255) NOT NULL,
        [Role] NVARCHAR(50) NOT NULL, -- Vendedora, Líder, Gerente
        [Store] NVARCHAR(255) NOT NULL,
        [PhoneE164] NVARCHAR(20) NOT NULL, -- Formato: +5511999999999
        [Status] NVARCHAR(20) NOT NULL DEFAULT 'active', -- active, inactive
        [ImportedAt] DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
        CONSTRAINT [UK_TeamMembers_Company_SellerCode] 
            UNIQUE ([CompanyCode], [SellerCode]),
        INDEX [IX_TeamMembers_Company_Active] ([CompanyCode]) WHERE [Status] = 'active'
    );

    PRINT 'Tabela TeamMembers criada com sucesso';
END
GO

-- Views para facilitar consultas

-- View: Vendas consolidadas por vendedor
CREATE OR ALTER VIEW [dbo].[vw_SalesBySellerMonth] AS
SELECT 
    s.[CompanyCode],
    s.[SellerCode],
    s.[SellerName],
    s.[Store],
    FORMAT(s.[Date], 'yyyy-MM') AS [Month],
    COUNT(DISTINCT s.[Date]) AS [DaysWithSales],
    SUM(s.[TotalValue]) AS [TotalRevenue],
    SUM(s.[ItemsQty]) AS [TotalItems],
    AVG(s.[AvgTicket]) AS [AvgTicket],
    COUNT(*) AS [TransactionCount]
FROM [dbo].[SalesData] s
GROUP BY 
    s.[CompanyCode],
    s.[SellerCode],
    s.[SellerName],
    s.[Store],
    FORMAT(s.[Date], 'yyyy-MM');
GO

-- View: Performance vs Meta
CREATE OR ALTER VIEW [dbo].[vw_PerformanceVsGoals] AS
SELECT 
    g.[CompanyCode],
    g.[Month],
    g.[Store],
    g.[SellerCode],
    t.[SellerName],
    g.[TargetValue],
    g.[TargetTicket],
    ISNULL(s.[TotalRevenue], 0) AS [ActualRevenue],
    ISNULL(s.[AvgTicket], 0) AS [ActualTicket],
    CASE 
        WHEN g.[TargetValue] > 0 THEN 
            (ISNULL(s.[TotalRevenue], 0) / g.[TargetValue]) * 100 
        ELSE 0 
    END AS [RevenuePercentage],
    g.[TargetValue] - ISNULL(s.[TotalRevenue], 0) AS [RevenueGap]
FROM [dbo].[GoalsData] g
LEFT JOIN [dbo].[vw_SalesBySellerMonth] s 
    ON g.[CompanyCode] = s.[CompanyCode] 
    AND g.[Month] = s.[Month]
    AND g.[SellerCode] = s.[SellerCode]
LEFT JOIN [dbo].[TeamMembers] t
    ON g.[CompanyCode] = t.[CompanyCode]
    AND g.[SellerCode] = t.[SellerCode];
GO

PRINT 'Views criadas com sucesso';
```

### Script 4: Tabelas de Chat e IA

```sql
-- scripts/03-create-chat-tables.sql
USE LiaXP;
GO

-- Tabela de Mensagens de Chat
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ChatMessages]'))
BEGIN
    CREATE TABLE [dbo].[ChatMessages] (
        [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        [CompanyCode] NVARCHAR(50) NOT NULL,
        [UserId] UNIQUEIDENTIFIER NOT NULL,
        [UserMessage] NVARCHAR(MAX) NOT NULL,
        [AssistantResponse] NVARCHAR(MAX) NOT NULL,
        [Intent] INT NOT NULL, -- Enum: ChatIntent
        [Metadata] NVARCHAR(MAX) NULL, -- JSON
        [CreatedAt] DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
        CONSTRAINT [FK_ChatMessages_Users] 
            FOREIGN KEY ([UserId]) REFERENCES [dbo].[Users]([Id]),
        INDEX [IX_ChatMessages_User_Date] ([UserId], [CreatedAt] DESC),
        INDEX [IX_ChatMessages_Company] ([CompanyCode], [CreatedAt] DESC)
    );

    PRINT 'Tabela ChatMessages criada com sucesso';
END
GO

-- Tabela de Insights Gerados
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Insights]'))
BEGIN
    CREATE TABLE [dbo].[Insights] (
        [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        [CompanyCode] NVARCHAR(50) NOT NULL,
        [Type] NVARCHAR(50) NOT NULL, -- goal_gap, tip, ranking, motivation
        [SellerCode] NVARCHAR(50) NULL,
        [Title] NVARCHAR(500) NOT NULL,
        [Content] NVARCHAR(MAX) NOT NULL,
        [Metadata] NVARCHAR(MAX) NULL, -- JSON
        [GeneratedAt] DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        [ExpiresAt] DATETIME2 NULL,
        
        INDEX [IX_Insights_Company_Type] ([CompanyCode], [Type], [GeneratedAt] DESC),
        INDEX [IX_Insights_Seller] ([CompanyCode], [SellerCode]) WHERE [SellerCode] IS NOT NULL
    );

    PRINT 'Tabela Insights criada com sucesso';
END
GO

-- Tabela de Prompts Customizados
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CustomPrompts]'))
BEGIN
    CREATE TABLE [dbo].[CustomPrompts] (
        [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        [CompanyCode] NVARCHAR(50) NOT NULL,
        [Name] NVARCHAR(100) NOT NULL,
        [Objective] NVARCHAR(500) NOT NULL,
        [Instructions] NVARCHAR(MAX) NOT NULL,
        [IsActive] BIT NOT NULL DEFAULT 1,
        [CreatedAt] DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        [UpdatedAt] DATETIME2 NULL,
        
        CONSTRAINT [UK_CustomPrompts_Company_Name] 
            UNIQUE ([CompanyCode], [Name]),
        INDEX [IX_CustomPrompts_Company_Active] ([CompanyCode]) WHERE [IsActive] = 1
    );

    PRINT 'Tabela CustomPrompts criada com sucesso';
END
GO

-- Dados iniciais de prompts (baseados no Excel)
INSERT INTO [dbo].[CustomPrompts] 
    ([Id], [CompanyCode], [Name], [Objective], [Instructions], [IsActive])
VALUES
    (NEWID(), 'DEMO', 'resumo_diario_loja', 
     'Gerar 3 forças, 3 oportunidades, 3 ações',
     'Você é a LIA, assistente de vendas. Analise metas x realizado, ticket, conversão e top categorias com os dados abaixo e escreva: (a) 3 forças, (b) 3 oportunidades, (c) 3 ações práticas para amanhã. Tom humano, positivo e direto.',
     1),
    
    (NEWID(), 'DEMO', 'alerta_queda_indicador',
     'Explicar queda e recomendar correções',
     'Explique a queda de {{indicador}} em {{loja}} hoje. Dê 2 hipóteses e 2 ações de correção para as próximas horas. Seja objetiva.',
     1),
    
    (NEWID(), 'DEMO', 'reconhecimento_individual',
     'Mensagem positiva para a pessoa destaque',
     'Crie uma mensagem curta e sincera para reconhecer {{nome}} pelo resultado de {{feito}} hoje. Evite clichês; use tom humano e caloroso.',
     1),
    
    (NEWID(), 'DEMO', 'dica_abordagem',
     'Sugestão de técnica de venda',
     'Dê 3 frases de abordagem consultiva para vender {{categoria}} a clientes que dizem que "vão pensar", com foco em benefício e experiência.',
     1),
    
    (NEWID(), 'DEMO', 'simulacao_objecao_preco',
     'Ensaiar resposta à objeção de preço',
     'Simule 3 respostas empáticas à frase "está caro" para {{produto}}, trazendo valor percebido, alternativa e fechamento leve.',
     1);

PRINT 'Prompts padrão inseridos com sucesso';
GO
```

### Script 5: Tabelas de Revisão e Mensagens

```sql
-- scripts/04-create-reviews-tables.sql
USE LiaXP;
GO

-- Tabela de Mensagens para Revisão (HITL - Human In The Loop)
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MessageReviews]'))
BEGIN
    CREATE TABLE [dbo].[MessageReviews] (
        [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        [CompanyCode] NVARCHAR(50) NOT NULL,
        [MessageType] NVARCHAR(50) NOT NULL, -- morning, midday, evening, alert
        [RecipientType] NVARCHAR(50) NOT NULL, -- seller, team, manager
        [RecipientId] NVARCHAR(50) NULL, -- SellerCode ou null para grupo
        [OriginalMessage] NVARCHAR(MAX) NOT NULL,
        [EditedMessage] NVARCHAR(MAX) NULL,
        [Status] NVARCHAR(20) NOT NULL DEFAULT 'pending', -- pending, approved, rejected, sent
        [CreatedAt] DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        [ReviewedAt] DATETIME2 NULL,
        [ReviewedBy] UNIQUEIDENTIFIER NULL,
        [SentAt] DATETIME2 NULL,
        [Metadata] NVARCHAR(MAX) NULL, -- JSON
        
        CONSTRAINT [FK_MessageReviews_ReviewedBy] 
            FOREIGN KEY ([ReviewedBy]) REFERENCES [dbo].[Users]([Id]),
        INDEX [IX_MessageReviews_Status] ([CompanyCode], [Status], [CreatedAt]),
        INDEX [IX_MessageReviews_Recipient] ([CompanyCode], [RecipientId], [Status])
    );

    PRINT 'Tabela MessageReviews criada com sucesso';
END
GO

-- Tabela de Histórico de Mensagens Enviadas
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SentMessages]'))
BEGIN
    CREATE TABLE [dbo].[SentMessages] (
        [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        [CompanyCode] NVARCHAR(50) NOT NULL,
        [ReviewId] UNIQUEIDENTIFIER NULL,
        [RecipientPhone] NVARCHAR(20) NOT NULL,
        [RecipientName] NVARCHAR(255) NOT NULL,
        [Message] NVARCHAR(MAX) NOT NULL,
        [Provider] NVARCHAR(20) NOT NULL, -- twilio, meta
        [ExternalId] NVARCHAR(255) NULL, -- ID da mensagem no provedor
        [Status] NVARCHAR(20) NOT NULL, -- sent, delivered, read, failed
        [SentAt] DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        [DeliveredAt] DATETIME2 NULL,
        [ReadAt] DATETIME2 NULL,
        [ErrorMessage] NVARCHAR(MAX) NULL,
        
        CONSTRAINT [FK_SentMessages_Review] 
            FOREIGN KEY ([ReviewId]) REFERENCES [dbo].[MessageReviews]([Id]),
        INDEX [IX_SentMessages_Company_Date] ([CompanyCode], [SentAt] DESC),
        INDEX [IX_SentMessages_Status] ([Status], [SentAt] DESC)
    );

    PRINT 'Tabela SentMessages criada com sucesso';
END
GO

-- Tabela de Agendamento de Mensagens (Cron Jobs)
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduledMessages]'))
BEGIN
    CREATE TABLE [dbo].[ScheduledMessages] (
        [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        [CompanyCode] NVARCHAR(50) NOT NULL,
        [Name] NVARCHAR(100) NOT NULL,
        [CronExpression] NVARCHAR(50) NOT NULL, -- Ex: "0 30 7 * * *" para 7:30
        [MessageType] NVARCHAR(50) NOT NULL,
        [TargetAudience] NVARCHAR(50) NOT NULL, -- all, sellers, managers
        [RequiresApproval] BIT NOT NULL DEFAULT 1,
        [IsActive] BIT NOT NULL DEFAULT 1,
        [LastRunAt] DATETIME2 NULL,
        [NextRunAt] DATETIME2 NULL,
        [CreatedAt] DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
        INDEX [IX_ScheduledMessages_NextRun] ([IsActive], [NextRunAt]) WHERE [IsActive] = 1
    );

    PRINT 'Tabela ScheduledMessages criada com sucesso';
END
GO

-- Inserir agendamentos padrão baseados na rotina da LIA
INSERT INTO [dbo].[ScheduledMessages]
    ([Id], [CompanyCode], [Name], [CronExpression], [MessageType], [TargetAudience], [RequiresApproval], [IsActive])
VALUES
    (NEWID(), 'DEMO', 'Resumo Matinal', '0 30 7 * * *', 'morning', 'managers', 1, 1),
    (NEWID(), 'DEMO', 'Dica do Meio-Dia', '0 30 11 * * *', 'midday', 'sellers', 1, 1),
    (NEWID(), 'DEMO', 'Ranking Parcial', '0 0 15 * * *', 'afternoon', 'all', 1, 1),
    (NEWID(), 'DEMO', 'Fechamento do Dia', '0 0 18 * * *', 'evening', 'all', 1, 1);

PRINT 'Agendamentos padrão inseridos com sucesso';
GO
```

### Script 6: Stored Procedures Úteis

```sql
-- scripts/05-create-stored-procedures.sql
USE LiaXP;
GO

-- SP: Obter performance atual do vendedor
CREATE OR ALTER PROCEDURE [dbo].[sp_GetSellerPerformance]
    @CompanyCode NVARCHAR(50),
    @SellerCode NVARCHAR(50),
    @Month NVARCHAR(7) = NULL -- Se NULL, usa mês atual
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @Month IS NULL
        SET @Month = FORMAT(GETDATE(), 'yyyy-MM');
    
    SELECT 
        p.[SellerCode],
        p.[SellerName],
        p.[Store],
        p.[TargetValue],
        p.[ActualRevenue],
        p.[RevenueGap],
        p.[RevenuePercentage],
        p.[TargetTicket],
        p.[ActualTicket],
        CASE 
            WHEN p.[ActualTicket] >= p.[TargetTicket] THEN 'Atingido'
            ELSE 'Abaixo da Meta'
        END AS [TicketStatus]
    FROM [dbo].[vw_PerformanceVsGoals] p
    WHERE p.[CompanyCode] = @CompanyCode
        AND p.[SellerCode] = @SellerCode
        AND p.[Month] = @Month;
END
GO

-- SP: Obter ranking de vendedores
CREATE OR ALTER PROCEDURE [dbo].[sp_GetSellerRanking]
    @CompanyCode NVARCHAR(50),
    @Month NVARCHAR(7) = NULL,
    @TopN INT = 10
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @Month IS NULL
        SET @Month = FORMAT(GETDATE(), 'yyyy-MM');
    
    SELECT TOP (@TopN)
        ROW_NUMBER() OVER (ORDER BY p.[ActualRevenue] DESC) AS [Ranking],
        p.[SellerCode],
        p.[SellerName],
        p.[Store],
        p.[ActualRevenue],
        p.[TargetValue],
        p.[RevenuePercentage],
        p.[ActualTicket]
    FROM [dbo].[vw_PerformanceVsGoals] p
    WHERE p.[CompanyCode] = @CompanyCode
        AND p.[Month] = @Month
        AND p.[ActualRevenue] > 0
    ORDER BY p.[ActualRevenue] DESC;
END
GO

-- SP: Calcular gap para meta (individual)
CREATE OR ALTER PROCEDURE [dbo].[sp_CalculateGoalGap]
    @CompanyCode NVARCHAR(50),
    @SellerCode NVARCHAR(50),
    @Month NVARCHAR(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @Month IS NULL
        SET @Month = FORMAT(GETDATE(), 'yyyy-MM');
    
    SELECT 
        p.[SellerCode],
        p.[SellerName],
        p.[TargetValue],
        p.[ActualRevenue],
        p.[RevenueGap],
        p.[RevenuePercentage],
        -- Calcular dias úteis restantes no mês
        DATEDIFF(DAY, GETDATE(), EOMONTH(GETDATE())) AS [DaysRemaining],
        -- Calcular venda média diária necessária
        CASE 
            WHEN DATEDIFF(DAY, GETDATE(), EOMONTH(GETDATE())) > 0 THEN
                p.[RevenueGap] / DATEDIFF(DAY, GETDATE(), EOMONTH(GETDATE()))
            ELSE 0
        END AS [DailyTargetNeeded]
    FROM [dbo].[vw_PerformanceVsGoals] p
    WHERE p.[CompanyCode] = @CompanyCode
        AND p.[SellerCode] = @SellerCode
        AND p.[Month] = @Month;
END
GO

-- SP: Obter top categorias por vendedor
CREATE OR ALTER PROCEDURE [dbo].[sp_GetTopCategoriesBySeller]
    @CompanyCode NVARCHAR(50),
    @SellerCode NVARCHAR(50),
    @Month NVARCHAR(7) = NULL,
    @TopN INT = 5
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @Month IS NULL
        SET @Month = FORMAT(GETDATE(), 'yyyy-MM');
    
    SELECT TOP (@TopN)
        s.[Category],
        SUM(s.[TotalValue]) AS [TotalRevenue],
        COUNT(*) AS [TransactionCount],
        AVG(s.[AvgTicket]) AS [AvgTicket]
    FROM [dbo].[SalesData] s
    WHERE s.[CompanyCode] = @CompanyCode
        AND s.[SellerCode] = @SellerCode
        AND FORMAT(s.[Date], 'yyyy-MM') = @Month
    GROUP BY s.[Category]
    ORDER BY SUM(s.[TotalValue]) DESC;
END
GO

PRINT 'Stored Procedures criadas com sucesso';
```

---

## ⚙️ Configuração do Projeto

### appsettings.json Completo

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost,1433;Database=LiaXP;User Id=sa;Password=YourStrongPassword123;TrustServerCertificate=True;MultipleActiveResultSets=true"
  },
  
  "Jwt": {
    "SigningKey": "your-super-secret-key-must-be-at-least-32-characters-long-for-security",
    "Issuer": "LiaXP-Api",
    "Audience": "LiaXP-Client",
    "ExpirationHours": 1
  },
  
  "OpenAI": {
    "ApiKey": "sk-your-openai-api-key-here",
    "Model": "gpt-4",
    "MaxTokens": 500,
    "Temperature": 0.7
  },
  
  "WhatsApp": {
    "Provider": "meta",
    "VerifyToken": "your-verify-token-here",
    
    "Meta": {
      "AccessToken": "your-meta-access-token",
      "PhoneNumberId": "your-phone-number-id",
      "AppSecret": "your-app-secret"
    },
    
    "Twilio": {
      "AccountSid": "AC...",
      "AuthToken": "your-auth-token",
      "FromNumber": "whatsapp:+14155238886"
    }
  },
  
  "RateLimiting": {
    "Enabled": true,
    "PermitLimit": 60,
    "Window": "00:01:00",
    "QueueLimit": 10
  },
  
  "Cors": {
    "AllowedOrigins": ["http://localhost:3000", "https://yourdomain.com"],
    "AllowedMethods": ["GET", "POST", "PUT", "DELETE", "PATCH"],
    "AllowedHeaders": ["*"]
  },
  
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning",
      "Microsoft.EntityFrameworkCore": "Warning"
    }
  },
  
  "AllowedHosts": "*"
}
```

### appsettings.Development.json

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost,1433;Database=LiaXP_Dev;User Id=sa;Password=DevPassword123;TrustServerCertificate=True"
  },
  
  "Jwt": {
    "SigningKey": "development-key-32-chars-minimum-length-required",
    "Issuer": "LiaXP-Dev",
    "Audience": "LiaXP-Dev-Client"
  },
  
  "OpenAI": {
    "ApiKey": "sk-dev-key",
    "Model": "gpt-3.5-turbo"
  },
  
  "Logging": {
    "LogLevel": {
      "Default": "Debug",
      "Microsoft.AspNetCore": "Information"
    }
  }
}
```

### .env.example

```.env
# Database
AZURE_SQL_CONNECTIONSTRING=Server=localhost;Database=LiaXP;User Id=sa;Password=YourPassword;TrustServerCertificate=True

# JWT
JWT_SIGNING_KEY=your-super-secret-key-min-32-characters
JWT_ISSUER=LiaXP-Api
JWT_AUDIENCE=LiaXP-Client

# OpenAI
OPENAI_API_KEY=sk-your-api-key-here
OPENAI_MODEL=gpt-4

# WhatsApp - Meta
WHATS_PROVIDER=meta
META_WA_TOKEN=your-access-token
META_WA_PHONE_ID=your-phone-number-id
META_WA_VERIFY_TOKEN=your-verify-token
META_WA_APP_SECRET=your-app-secret

# WhatsApp - Twilio (alternativo)
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=your-auth-token
TWILIO_FROM=whatsapp:+14155238886

# Azure (Produção)
AZURE_RESOURCE_GROUP=liaxp-rg
AZURE_APP_SERVICE=liaxp-api
AZURE_REGION=eastus
```

---

## 🚀 Guia de Implementação Passo a Passo

### Passo 1: Preparar o Ambiente

```bash
# 1. Instalar .NET 8 SDK
# Download: https://dotnet.microsoft.com/download/dotnet/8.0

# 2. Verificar instalação
dotnet --version

# 3. Instalar SQL Server
# Docker: docker run -e "ACCEPT_EULA=Y" -e "MSSQL_SA_PASSWORD=YourPassword123" -p 1433:1433 -d mcr.microsoft.com/mssql/server:2022-latest

# 4. Clonar o repositório
git clone https://github.com/alshashiguchi/LiaXPv2.git
cd LiaXPv2
```

### Passo 2: Executar Scripts SQL

```bash
# Conectar ao SQL Server
sqlcmd -S localhost -U sa -P YourPassword123

# Ou usar Azure Data Studio / SSMS

# Executar na ordem:
# 1. 00-init-database.sql
# 2. 01-create-users-table.sql
# 3. 02-create-sales-tables.sql
# 4. 03-create-chat-tables.sql
# 5. 04-create-reviews-tables.sql
# 6. 05-create-stored-procedures.sql
```

### Passo 3: Configurar Credenciais

```bash
# Copiar exemplo de configuração
cp appsettings.Example.json appsettings.Development.json

# Editar com suas credenciais
nano appsettings.Development.json

# Configurar secrets (produção)
dotnet user-secrets init --project src/LiaXP.Api
dotnet user-secrets set "Jwt:SigningKey" "your-key" --project src/LiaXP.Api
dotnet user-secrets set "OpenAI:ApiKey" "sk-..." --project src/LiaXP.Api
```

### Passo 4: Instalar Dependências

```bash
cd src/LiaXP.Api

# Restaurar pacotes
dotnet restore

# Adicionar pacotes necessários (se ainda não estiverem no .csproj)
dotnet add package Microsoft.AspNetCore.Authentication.JwtBearer --version 8.0.0
dotnet add package Dapper --version 2.1.24
dotnet add package ClosedXML --version 0.102.1
dotnet add package System.IdentityModel.Tokens.Jwt --version 7.0.3
dotnet add package Swashbuckle.AspNetCore --version 6.5.0
```

### Passo 5: Criar Hash de Senha Inicial

```csharp
// Executar este código para gerar hash da senha padrão
using LiaXP.Infrastructure.Services;

var hasher = new PasswordHasher();
var hash = hasher.HashPassword("Admin@123");
Console.WriteLine($"Hash: {hash}");

// Atualizar no banco:
// UPDATE Users SET PasswordHash = '{hash}' WHERE Email = 'admin@liaxp.com'
```

### Passo 6: Executar a Aplicação

```bash
# Desenvolvimento
cd src/LiaXP.Api
dotnet run

# Ou com hot reload
dotnet watch run

# A API estará disponível em:
# https://localhost:5001
# http://localhost:5000
```

### Passo 7: Testar Autenticação

```bash
# 1. Testar health check
curl http://localhost:5000/healthz

# 2. Fazer login
curl -X POST "http://localhost:5000/auth/token" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@liaxp.com",
    "password": "Admin@123",
    "companyCode": "DEMO"
  }'

# 3. Copiar o token da resposta

# 4. Testar endpoint protegido
curl -X POST "http://localhost:5000/chat" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer SEU_TOKEN_AQUI" \
  -d '{
    "message": "quanto falta pra meta?"
  }'
```

### Passo 8: Importar Dados de Exemplo

```bash
# Usar o arquivo LIA_starter_kit.xlsx
curl -X POST "http://localhost:5000/data/import/xlsx?retrain=true" \
  -H "Authorization: Bearer SEU_TOKEN" \
  -F "file=@./LIA_starter_kit.xlsx"
```

---

## 📦 Estrutura Final de Arquivos

```
LiaXPv2/
├── scripts/
│   ├── 00-init-database.sql
│   ├── 01-create-users-table.sql
│   ├── 02-create-sales-tables.sql
│   ├── 03-create-chat-tables.sql
│   ├── 04-create-reviews-tables.sql
│   └── 05-create-stored-procedures.sql
│
├── src/
│   ├── LiaXP.Domain/
│   │   ├── Entities/
│   │   │   ├── User.cs
│   │   │   ├── SalesData.cs
│   │   │   ├── ChatMessage.cs
│   │   │   └── ...
│   │   ├── Interfaces/
│   │   │   ├── IUserRepository.cs
│   │   │   ├── IPasswordHasher.cs
│   │   │   ├── ITokenService.cs
│   │   │   └── ...
│   │   └── LiaXP.Domain.csproj
│   │
│   ├── LiaXP.Application/
│   │   ├── DTOs/
│   │   ├── UseCases/
│   │   │   ├── Auth/
│   │   │   │   └── LoginUseCase.cs
│   │   │   ├── Chat/
│   │   │   ├── Data/
│   │   │   └── ...
│   │   └── LiaXP.Application.csproj
│   │
│   ├── LiaXP.Infrastructure/
│   │   ├── Data/
│   │   │   └── Repositories/
│   │   │       └── UserRepository.cs
│   │   ├── Services/
│   │   │   ├── PasswordHasher.cs
│   │   │   ├── JwtTokenService.cs
│   │   │   ├── OpenAIService.cs
│   │   │   └── ExcelImportService.cs
│   │   └── LiaXP.Infrastructure.csproj
│   │
│   └── LiaXP.Api/
│       ├── Controllers/
│       │   ├── AuthController.cs
│       │   ├── ChatController.cs
│       │   ├── DataController.cs
│       │   ├── WebhookController.cs
│       │   └── CronController.cs
│       ├── Middleware/
│       ├── Program.cs
│       ├── appsettings.json
│       ├── appsettings.Development.json
│       └── LiaXP.Api.csproj
│
├── .gitignore
├── README.md
├── Dockerfile
└── docker-compose.yml
```

---

## 🔍 Próximos Passos de Desenvolvimento

1. **Implementar endpoints faltantes**:
   - `/insights` - Buscar insights gerados
   - `/reviews/pending` - Listar mensagens pendentes
   - `/reviews/{id}/approve` - Aprovar mensagem
   - `/reviews/{id}/edit-and-approve` - Editar e aprovar

2. **Adicionar testes unitários**:
   ```bash
   dotnet new xunit -n LiaXP.Tests
   dotnet add reference ../src/LiaXP.Application
   ```

3. **Configurar CI/CD**:
   - GitHub Actions
   - Azure DevOps Pipeline

4. **Implementar Rate Limiting**:
   ```csharp
   builder.Services.AddRateLimiter(options => { ... });
   ```

5. **Adicionar Logging estruturado**:
   ```csharp
   builder.Services.AddSerilog();
   ```

---

## 🎯 Checklist de Implementação

- [x] Estrutura de camadas (DDD/Clean Architecture)
- [x] Endpoint `/auth/token` completo
- [x] Endpoint `/chat` completo
- [x] Endpoint `/data/import/xlsx` completo
- [x] Endpoint `/webhook/whatsapp` completo
- [x] Scripts SQL completos
- [ ] Testes unitários
- [ ] Documentação Swagger completa
- [ ] Deploy Azure
- [ ] Monitoramento e logs

---

## 📚 Recursos e Referências

- [Clean Architecture - Uncle Bob](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html)
- [DDD - Eric Evans](https://www.domainlanguage.com/ddd/)
- [.NET Documentation](https://docs.microsoft.com/dotnet/)
- [JWT Best Practices](https://tools.ietf.org/html/rfc8725)
- [OpenAI API](https://platform.openai.com/docs)
- [WhatsApp Business API](https://developers.facebook.com/docs/whatsapp)
