#!/bin/bash

# LiaXP - Setup Automatizado (Linux/Mac)
# Este script automatiza a configuração inicial do projeto LiaXP

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Variáveis padrão
CONNECTION_STRING="Server=localhost,1433;Database=LiaXP;User Id=sa;Password=YourPassword123;TrustServerCertificate=True"
JWT_SIGNING_KEY="your-super-secret-key-must-be-32-chars-minimum"
SKIP_DATABASE=false
SKIP_NUGET=false

# Funções auxiliares
print_header() {
    echo -e "${CYAN}========================================${NC}"
    echo -e "${CYAN}    LiaXP - Setup Automatizado${NC}"
    echo -e "${CYAN}========================================${NC}"
    echo ""
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "${CYAN}$1${NC}"
}

show_help() {
    cat << EOF
LiaXP - Setup Automatizado
===========================

Uso: ./setup-liaxp.sh [options]

Opções:
  -c, --connection-string <string>  Connection string do SQL Server
  -k, --jwt-key <string>            Chave JWT (min 32 caracteres)
  --skip-database                   Pula configuração do banco de dados
  --skip-nuget                      Pula instalação de pacotes NuGet
  -h, --help                        Mostra esta mensagem

Exemplo:
  ./setup-liaxp.sh -c "Server=localhost;Database=LiaXP;..." -k "my-secret-key"

EOF
    exit 0
}

# Parse argumentos
while [[ $# -gt 0 ]]; do
    case $1 in
        -c|--connection-string)
            CONNECTION_STRING="$2"
            shift 2
            ;;
        -k|--jwt-key)
            JWT_SIGNING_KEY="$2"
            shift 2
            ;;
        --skip-database)
            SKIP_DATABASE=true
            shift
            ;;
        --skip-nuget)
            SKIP_NUGET=true
            shift
            ;;
        -h|--help)
            show_help
            ;;
        *)
            echo "Opção desconhecida: $1"
            show_help
            ;;
    esac
done

# Início do script
print_header

# Verificar pré-requisitos
echo -e "${YELLOW}Verificando pré-requisitos...${NC}"

# 1. Verificar .NET SDK
echo -n "  [1/3] Verificando .NET SDK... "
if command -v dotnet &> /dev/null; then
    DOTNET_VERSION=$(dotnet --version)
    print_success "OK (v$DOTNET_VERSION)"
else
    print_error "ERRO"
    echo "    .NET SDK não encontrado. Instale de: https://dotnet.microsoft.com/download"
    exit 1
fi

# 2. Verificar SQL Server (opcional)
echo -n "  [2/3] Verificando SQL Server... "
if command -v sqlcmd &> /dev/null; then
    print_success "OK"
else
    print_warning "AVISO (opcional)"
    echo "    sqlcmd não encontrado. Configure SQL Server manualmente se necessário."
fi

# 3. Verificar Git
echo -n "  [3/3] Verificando Git... "
if command -v git &> /dev/null; then
    GIT_VERSION=$(git --version)
    print_success "OK ($GIT_VERSION)"
else
    print_warning "AVISO (opcional)"
fi

echo ""

# Criar estrutura de diretórios
echo -e "${YELLOW}Criando estrutura de diretórios...${NC}"

DIRECTORIES=(
    "src/LiaXP.Domain/Entities"
    "src/LiaXP.Domain/Interfaces"
    "src/LiaXP.Domain/ValueObjects"
    "src/LiaXP.Application/DTOs/Auth"
    "src/LiaXP.Application/DTOs/Chat"
    "src/LiaXP.Application/UseCases/Auth"
    "src/LiaXP.Application/UseCases/Chat"
    "src/LiaXP.Application/UseCases/Data"
    "src/LiaXP.Infrastructure/Data/Repositories"
    "src/LiaXP.Infrastructure/Services"
    "src/LiaXP.Api/Controllers"
    "scripts"
)

for dir in "${DIRECTORIES[@]}"; do
    if [ ! -d "$dir" ]; then
        mkdir -p "$dir"
        print_success "$dir"
    fi
done

echo ""

# Instalar pacotes NuGet
if [ "$SKIP_NUGET" = false ]; then
    echo -e "${YELLOW}Instalando pacotes NuGet...${NC}"
    
    cd src/LiaXP.Api || exit
    
    PACKAGES=(
        "Microsoft.AspNetCore.Authentication.JwtBearer:8.0.0"
        "System.IdentityModel.Tokens.Jwt:7.0.3"
        "Dapper:2.1.24"
        "Microsoft.Data.SqlClient:5.1.5"
        "ClosedXML:0.102.1"
        "Swashbuckle.AspNetCore:6.5.0"
    )
    
    for package in "${PACKAGES[@]}"; do
        IFS=':' read -ra ADDR <<< "$package"
        PACKAGE_NAME="${ADDR[0]}"
        PACKAGE_VERSION="${ADDR[1]}"
        
        echo -n "  Instalando $PACKAGE_NAME... "
        if dotnet add package "$PACKAGE_NAME" --version "$PACKAGE_VERSION" &> /dev/null; then
            print_success "OK"
        else
            print_error "ERRO"
        fi
    done
    
    cd ../.. || exit
    echo ""
fi

# Configurar appsettings.json
echo -e "${YELLOW}Configurando appsettings.json...${NC}"

cat > src/LiaXP.Api/appsettings.json << EOF
{
  "ConnectionStrings": {
    "DefaultConnection": "$CONNECTION_STRING"
  },
  "Jwt": {
    "SigningKey": "$JWT_SIGNING_KEY",
    "Issuer": "LiaXP-Api",
    "Audience": "LiaXP-Client"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
EOF

print_success "appsettings.json criado"
echo ""

# Configurar banco de dados
if [ "$SKIP_DATABASE" = false ]; then
    echo -e "${YELLOW}Configurando banco de dados...${NC}"
    
    SQL_SCRIPTS=(
        "00-init-database.sql"
        "01-create-users-table.sql"
        "02-create-sales-tables.sql"
        "03-create-chat-tables.sql"
        "04-create-reviews-tables.sql"
        "05-create-stored-procedures.sql"
    )
    
    for script in "${SQL_SCRIPTS[@]}"; do
        if [ -f "scripts/$script" ]; then
            echo -n "  Executando $script... "
            if command -v sqlcmd &> /dev/null; then
                if sqlcmd -S localhost -U sa -P YourPassword123 -i "scripts/$script" &> /dev/null; then
                    print_success "OK"
                else
                    print_error "ERRO"
                fi
            else
                print_warning "sqlcmd não disponível"
            fi
        else
            print_warning "$script não encontrado (pule com --skip-database)"
        fi
    done
    
    echo ""
fi

# Gerar hash de senha padrão
echo -e "${YELLOW}Gerando hash de senha padrão...${NC}"

# Criar script C# temporário para gerar hash
TEMP_SCRIPT=$(mktemp).cs

cat > "$TEMP_SCRIPT" << 'EOF'
using System;
using System.Security.Cryptography;
using System.Text;

public class PasswordHasher
{
    public static string HashPassword(string password)
    {
        using var sha256 = SHA256.Create();
        var saltedPassword = password + "LiaXP_Salt_Key";
        var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(saltedPassword));
        return Convert.ToBase64String(bytes);
    }
}

Console.WriteLine(PasswordHasher.HashPassword("Admin@123"));
EOF

if command -v dotnet &> /dev/null; then
    HASH=$(dotnet script eval "$TEMP_SCRIPT" 2>/dev/null)
    if [ -n "$HASH" ]; then
        print_success "Hash gerado: $HASH"
        print_info "  Use este hash no INSERT da tabela Users"
    else
        print_warning "Não foi possível gerar o hash automaticamente"
        print_info "  Execute manualmente após iniciar o projeto"
    fi
else
    print_warning "dotnet não disponível para gerar hash"
fi

rm -f "$TEMP_SCRIPT"
echo ""

# Compilar projeto
echo -e "${YELLOW}Compilando projeto...${NC}"

cd src/LiaXP.Api || exit
if dotnet build &> /dev/null; then
    print_success "Compilação bem-sucedida"
else
    print_error "Erro na compilação. Verifique os logs."
fi
cd ../.. || exit

echo ""

# Resumo
echo -e "${CYAN}========================================${NC}"
echo -e "${CYAN}         Setup Concluído!${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""
echo -e "${YELLOW}Próximos passos:${NC}"
echo -e "${NC}  1. Revise os arquivos de documentação:${NC}"
echo -e "     ${CYAN}- 00_LEIA_PRIMEIRO_Executive_Summary.md${NC}"
echo -e "     ${CYAN}- LiaXP_Quick_Fix_Guide.md${NC}"
echo ""
echo -e "${NC}  2. Execute o projeto:${NC}"
echo -e "     ${CYAN}cd src/LiaXP.Api${NC}"
echo -e "     ${CYAN}dotnet run${NC}"
echo ""
echo -e "${NC}  3. Acesse o Swagger:${NC}"
echo -e "     ${CYAN}http://localhost:5000/swagger${NC}"
echo ""
echo -e "${NC}  4. Teste o endpoint /auth/token:${NC}"
echo -e "     ${CYAN}curl -X POST 'http://localhost:5000/auth/token' \\${NC}"
echo -e "       ${CYAN}-H 'Content-Type: application/json' \\${NC}"
echo -e "       ${CYAN}-d '{\"email\":\"admin@liaxp.com\",\"password\":\"Admin@123\",\"companyCode\":\"DEMO\"}'${NC}"
echo ""
echo -e "${GREEN}Boa sorte! 🚀${NC}"
