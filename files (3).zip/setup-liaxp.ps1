# LiaXP - Setup Automatizado (Windows)
# Este script automatiza a configuração inicial do projeto LiaXP

param(
    [string]$ConnectionString = "Server=localhost,1433;Database=LiaXP;User Id=sa;Password=YourPassword123;TrustServerCertificate=True",
    [string]$JwtSigningKey = "your-super-secret-key-must-be-32-chars-minimum",
    [switch]$SkipDatabase,
    [switch]$SkipNuget,
    [switch]$Help
)

function Show-Help {
    Write-Host @"
LiaXP - Setup Automatizado
===========================

Uso: .\setup-liaxp.ps1 [options]

Opções:
  -ConnectionString <string>  Connection string do SQL Server
  -JwtSigningKey <string>     Chave JWT (min 32 caracteres)
  -SkipDatabase               Pula configuração do banco de dados
  -SkipNuget                  Pula instalação de pacotes NuGet
  -Help                       Mostra esta mensagem

Exemplo:
  .\setup-liaxp.ps1 -ConnectionString "Server=localhost;Database=LiaXP;..."

"@
    exit 0
}

if ($Help) {
    Show-Help
}

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "    LiaXP - Setup Automatizado" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Verificar pré-requisitos
Write-Host "Verificando pré-requisitos..." -ForegroundColor Yellow

# 1. Verificar .NET SDK
Write-Host "  [1/3] Verificando .NET SDK..." -NoNewline
$dotnetVersion = dotnet --version 2>$null
if ($LASTEXITCODE -eq 0) {
    Write-Host " OK (v$dotnetVersion)" -ForegroundColor Green
} else {
    Write-Host " ERRO" -ForegroundColor Red
    Write-Host "    .NET SDK não encontrado. Instale de: https://dotnet.microsoft.com/download" -ForegroundColor Red
    exit 1
}

# 2. Verificar SQL Server
Write-Host "  [2/3] Verificando SQL Server..." -NoNewline
try {
    $sqlTest = Invoke-Sqlcmd -Query "SELECT @@VERSION" -ServerInstance "localhost" -TrustServerCertificate -ErrorAction Stop 2>$null
    Write-Host " OK" -ForegroundColor Green
} catch {
    Write-Host " AVISO" -ForegroundColor Yellow
    Write-Host "    SQL Server pode não estar acessível. Configure manualmente se necessário." -ForegroundColor Yellow
}

# 3. Verificar Git
Write-Host "  [3/3] Verificando Git..." -NoNewline
$gitVersion = git --version 2>$null
if ($LASTEXITCODE -eq 0) {
    Write-Host " OK ($gitVersion)" -ForegroundColor Green
} else {
    Write-Host " AVISO (opcional)" -ForegroundColor Yellow
}

Write-Host ""

# Criar estrutura de diretórios
Write-Host "Criando estrutura de diretórios..." -ForegroundColor Yellow

$directories = @(
    "src/LiaXP.Domain/Entities",
    "src/LiaXP.Domain/Interfaces",
    "src/LiaXP.Domain/ValueObjects",
    "src/LiaXP.Application/DTOs/Auth",
    "src/LiaXP.Application/DTOs/Chat",
    "src/LiaXP.Application/UseCases/Auth",
    "src/LiaXP.Application/UseCases/Chat",
    "src/LiaXP.Application/UseCases/Data",
    "src/LiaXP.Infrastructure/Data/Repositories",
    "src/LiaXP.Infrastructure/Services",
    "src/LiaXP.Api/Controllers",
    "scripts"
)

foreach ($dir in $directories) {
    if (!(Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "  ✓ $dir" -ForegroundColor Green
    }
}

Write-Host ""

# Instalar pacotes NuGet
if (!$SkipNuget) {
    Write-Host "Instalando pacotes NuGet..." -ForegroundColor Yellow
    
    $packages = @(
        @{ Name = "Microsoft.AspNetCore.Authentication.JwtBearer"; Version = "8.0.0" },
        @{ Name = "System.IdentityModel.Tokens.Jwt"; Version = "7.0.3" },
        @{ Name = "Dapper"; Version = "2.1.24" },
        @{ Name = "Microsoft.Data.SqlClient"; Version = "5.1.5" },
        @{ Name = "ClosedXML"; Version = "0.102.1" },
        @{ Name = "Swashbuckle.AspNetCore"; Version = "6.5.0" }
    )
    
    Push-Location "src/LiaXP.Api"
    foreach ($package in $packages) {
        Write-Host "  Instalando $($package.Name)..." -NoNewline
        dotnet add package $package.Name --version $package.Version >$null 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Host " OK" -ForegroundColor Green
        } else {
            Write-Host " ERRO" -ForegroundColor Red
        }
    }
    Pop-Location
    
    Write-Host ""
}

# Configurar appsettings.json
Write-Host "Configurando appsettings.json..." -ForegroundColor Yellow

$appsettings = @{
    ConnectionStrings = @{
        DefaultConnection = $ConnectionString
    }
    Jwt = @{
        SigningKey = $JwtSigningKey
        Issuer = "LiaXP-Api"
        Audience = "LiaXP-Client"
    }
    Logging = @{
        LogLevel = @{
            Default = "Information"
            "Microsoft.AspNetCore" = "Warning"
        }
    }
} | ConvertTo-Json -Depth 5

$appsettings | Out-File -FilePath "src/LiaXP.Api/appsettings.json" -Encoding UTF8
Write-Host "  ✓ appsettings.json criado" -ForegroundColor Green

Write-Host ""

# Configurar banco de dados
if (!$SkipDatabase) {
    Write-Host "Configurando banco de dados..." -ForegroundColor Yellow
    
    $sqlScripts = @(
        "00-init-database.sql",
        "01-create-users-table.sql",
        "02-create-sales-tables.sql",
        "03-create-chat-tables.sql",
        "04-create-reviews-tables.sql",
        "05-create-stored-procedures.sql"
    )
    
    foreach ($script in $sqlScripts) {
        if (Test-Path "scripts/$script") {
            Write-Host "  Executando $script..." -NoNewline
            try {
                Invoke-Sqlcmd -InputFile "scripts/$script" -ServerInstance "localhost" -TrustServerCertificate -ErrorAction Stop >$null
                Write-Host " OK" -ForegroundColor Green
            } catch {
                Write-Host " ERRO" -ForegroundColor Red
                Write-Host "    $($_.Exception.Message)" -ForegroundColor Red
            }
        } else {
            Write-Host "  ⚠ $script não encontrado (pule com -SkipDatabase)" -ForegroundColor Yellow
        }
    }
    
    Write-Host ""
}

# Gerar hash de senha padrão
Write-Host "Gerando hash de senha padrão..." -ForegroundColor Yellow

$passwordHasher = @"
using System;
using System.Security.Cryptography;
using System.Text;

public class PasswordHasher
{
    public static string HashPassword(string password)
    {
        using var sha256 = SHA256.Create();
        var saltedPassword = password + "LiaXP_Salt_Key";
        var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(saltedPassword));
        return Convert.ToBase64String(bytes);
    }
}

public class Program
{
    public static void Main()
    {
        Console.WriteLine(PasswordHasher.HashPassword("Admin@123"));
    }
}
"@

$tempFile = [System.IO.Path]::GetTempFileName() + ".cs"
$passwordHasher | Out-File -FilePath $tempFile -Encoding UTF8

$hash = dotnet script eval $tempFile 2>$null
if ($hash) {
    Write-Host "  Hash gerado: $hash" -ForegroundColor Green
    Write-Host "  Use este hash no INSERT da tabela Users" -ForegroundColor Cyan
} else {
    Write-Host "  ⚠ Não foi possível gerar o hash automaticamente" -ForegroundColor Yellow
    Write-Host "  Execute manualmente após iniciar o projeto" -ForegroundColor Yellow
}

Remove-Item $tempFile -Force -ErrorAction SilentlyContinue

Write-Host ""

# Compilar projeto
Write-Host "Compilando projeto..." -ForegroundColor Yellow

Push-Location "src/LiaXP.Api"
dotnet build >$null 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "  ✓ Compilação bem-sucedida" -ForegroundColor Green
} else {
    Write-Host "  ✗ Erro na compilação. Verifique os logs." -ForegroundColor Red
}
Pop-Location

Write-Host ""

# Resumo
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "         Setup Concluído!" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Próximos passos:" -ForegroundColor Yellow
Write-Host "  1. Revise os arquivos de documentação:" -ForegroundColor White
Write-Host "     - 00_LEIA_PRIMEIRO_Executive_Summary.md" -ForegroundColor Cyan
Write-Host "     - LiaXP_Quick_Fix_Guide.md" -ForegroundColor Cyan
Write-Host ""
Write-Host "  2. Execute o projeto:" -ForegroundColor White
Write-Host "     cd src/LiaXP.Api" -ForegroundColor Cyan
Write-Host "     dotnet run" -ForegroundColor Cyan
Write-Host ""
Write-Host "  3. Acesse o Swagger:" -ForegroundColor White
Write-Host "     http://localhost:5000/swagger" -ForegroundColor Cyan
Write-Host ""
Write-Host "  4. Teste o endpoint /auth/token:" -ForegroundColor White
Write-Host "     curl -X POST 'http://localhost:5000/auth/token' \" -ForegroundColor Cyan
Write-Host "       -H 'Content-Type: application/json' \" -ForegroundColor Cyan
Write-Host "       -d '{""email"":""admin@liaxp.com"",""password"":""Admin@123"",""companyCode"":""DEMO""}'" -ForegroundColor Cyan
Write-Host ""
Write-Host "Boa sorte! 🚀" -ForegroundColor Green
