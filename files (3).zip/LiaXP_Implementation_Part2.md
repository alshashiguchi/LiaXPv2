# LiaXP - Implementação dos Demais Endpoints (Parte 2)

## 📋 Índice de Endpoints

1. ✅ `/auth/token` - Autenticação (Parte 1)
2. 🔄 `/chat` - Chat com IA
3. 📊 `/data/import/xlsx` - Importação de dados Excel
4. 📈 `/insights` - Insights de vendas
5. 📱 `/webhook/whatsapp` - Webhook WhatsApp
6. ⏰ `/cron/run-now` - Executar mensagens agendadas
7. 🔍 `/data/status` - Status de importação
8. ✏️ `/reviews/{id}/approve` - Aprovar mensagens
9. ✏️ `/reviews/{id}/edit-and-approve` - Editar e aprovar mensagens

---

## 💬 2. Endpoint de Chat (/chat)

### 2.1 Domain Layer

#### `src/LiaXP.Domain/Entities/ChatMessage.cs`
```csharp
namespace LiaXP.Domain.Entities;

public class ChatMessage
{
    public Guid Id { get; private set; }
    public string CompanyCode { get; private set; }
    public Guid UserId { get; private set; }
    public string UserMessage { get; private set; }
    public string AssistantResponse { get; private set; }
    public ChatIntent Intent { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public Dictionary<string, string> Metadata { get; private set; }

    private ChatMessage() { }

    public ChatMessage(
        string companyCode,
        Guid userId,
        string userMessage,
        string assistantResponse,
        ChatIntent intent,
        Dictionary<string, string>? metadata = null)
    {
        Id = Guid.NewGuid();
        CompanyCode = companyCode;
        UserId = userId;
        UserMessage = userMessage;
        AssistantResponse = assistantResponse;
        Intent = intent;
        CreatedAt = DateTime.UtcNow;
        Metadata = metadata ?? new Dictionary<string, string>();
    }
}

public enum ChatIntent
{
    Unknown = 0,
    GoalGap = 1,          // "quanto falta pra meta?"
    Tips = 2,             // "dica de abordagem"
    Ranking = 3,          // "ranking de vendas"
    SellerPerformance = 4, // "como está a Ana?"
    TeamMotivation = 5,    // "mensagem motivacional"
    ProductHelp = 6,       // "como vender skincare?"
    GeneralQuestion = 7    // perguntas gerais
}
```

#### `src/LiaXP.Domain/Interfaces/IChatRepository.cs`
```csharp
namespace LiaXP.Domain.Interfaces;

public interface IChatRepository
{
    Task SaveMessageAsync(ChatMessage message, CancellationToken cancellationToken = default);
    Task<List<ChatMessage>> GetUserHistoryAsync(
        Guid userId, 
        int limit = 10, 
        CancellationToken cancellationToken = default);
}
```

#### `src/LiaXP.Domain/Interfaces/IAIService.cs`
```csharp
namespace LiaXP.Domain.Interfaces;

public interface IAIService
{
    Task<AIResponse> ProcessMessageAsync(
        string message, 
        string companyCode,
        Dictionary<string, object>? context = null,
        CancellationToken cancellationToken = default);
    
    ChatIntent DetectIntent(string message);
}

public class AIResponse
{
    public string Message { get; set; } = string.Empty;
    public ChatIntent Intent { get; set; }
    public Dictionary<string, string> Metadata { get; set; } = new();
}
```

---

### 2.2 Application Layer

#### `src/LiaXP.Application/DTOs/Chat/ChatRequest.cs`
```csharp
namespace LiaXP.Application.DTOs.Chat;

public record ChatRequest
{
    public string Message { get; init; } = string.Empty;
}
```

#### `src/LiaXP.Application/DTOs/Chat/ChatResponse.cs`
```csharp
namespace LiaXP.Application.DTOs.Chat;

public record ChatResponse
{
    public string Message { get; init; } = string.Empty;
    public string Intent { get; init; } = string.Empty;
    public DateTime Timestamp { get; init; }
}
```

#### `src/LiaXP.Application/UseCases/Chat/ProcessChatUseCase.cs`
```csharp
using LiaXP.Application.DTOs.Chat;
using LiaXP.Domain.Entities;
using LiaXP.Domain.Interfaces;
using Microsoft.Extensions.Logging;

namespace LiaXP.Application.UseCases.Chat;

public interface IProcessChatUseCase
{
    Task<Result<ChatResponse>> ExecuteAsync(
        ChatRequest request,
        Guid userId,
        string companyCode,
        CancellationToken cancellationToken = default);
}

public class ProcessChatUseCase : IProcessChatUseCase
{
    private readonly IAIService _aiService;
    private readonly IChatRepository _chatRepository;
    private readonly ILogger<ProcessChatUseCase> _logger;

    public ProcessChatUseCase(
        IAIService aiService,
        IChatRepository chatRepository,
        ILogger<ProcessChatUseCase> logger)
    {
        _aiService = aiService;
        _chatRepository = chatRepository;
        _logger = logger;
    }

    public async Task<Result<ChatResponse>> ExecuteAsync(
        ChatRequest request,
        Guid userId,
        string companyCode,
        CancellationToken cancellationToken = default)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(request.Message))
            {
                return Result<ChatResponse>.Failure("Mensagem não pode estar vazia");
            }

            // Detectar intent
            var intent = _aiService.DetectIntent(request.Message);

            // Buscar contexto necessário baseado no intent
            var context = await BuildContextForIntent(intent, companyCode, cancellationToken);

            // Processar mensagem com IA
            var aiResponse = await _aiService.ProcessMessageAsync(
                request.Message,
                companyCode,
                context,
                cancellationToken);

            // Salvar histórico
            var chatMessage = new ChatMessage(
                companyCode,
                userId,
                request.Message,
                aiResponse.Message,
                aiResponse.Intent,
                aiResponse.Metadata);

            await _chatRepository.SaveMessageAsync(chatMessage, cancellationToken);

            var response = new ChatResponse
            {
                Message = aiResponse.Message,
                Intent = aiResponse.Intent.ToString(),
                Timestamp = DateTime.UtcNow
            };

            _logger.LogInformation(
                "Mensagem processada com sucesso. UserId: {UserId}, Intent: {Intent}",
                userId,
                aiResponse.Intent);

            return Result<ChatResponse>.Success(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao processar chat para usuário {UserId}", userId);
            return Result<ChatResponse>.Failure("Erro ao processar mensagem");
        }
    }

    private async Task<Dictionary<string, object>> BuildContextForIntent(
        ChatIntent intent,
        string companyCode,
        CancellationToken cancellationToken)
    {
        var context = new Dictionary<string, object>();

        // Adicionar contexto específico baseado no intent
        // Por exemplo, para GoalGap, buscar metas e vendas atuais
        // Para Tips, buscar melhores práticas e prompts
        // etc.

        return context;
    }
}
```

---

### 2.3 Infrastructure Layer

#### `src/LiaXP.Infrastructure/Services/OpenAIService.cs`
```csharp
using LiaXP.Domain.Entities;
using LiaXP.Domain.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace LiaXP.Infrastructure.Services;

public class OpenAIService : IAIService
{
    private readonly HttpClient _httpClient;
    private readonly string _apiKey;
    private readonly string _model;
    private readonly ILogger<OpenAIService> _logger;

    public OpenAIService(
        HttpClient httpClient,
        IConfiguration configuration,
        ILogger<OpenAIService> logger)
    {
        _httpClient = httpClient;
        _apiKey = configuration["OpenAI:ApiKey"] 
            ?? throw new InvalidOperationException("OpenAI API Key não configurada");
        _model = configuration["OpenAI:Model"] ?? "gpt-4";
        _logger = logger;

        _httpClient.BaseAddress = new Uri("https://api.openai.com/v1/");
        _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {_apiKey}");
    }

    public async Task<AIResponse> ProcessMessageAsync(
        string message,
        string companyCode,
        Dictionary<string, object>? context = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var intent = DetectIntent(message);
            var systemPrompt = BuildSystemPrompt(intent, context);

            var requestBody = new
            {
                model = _model,
                messages = new[]
                {
                    new { role = "system", content = systemPrompt },
                    new { role = "user", content = message }
                },
                temperature = 0.7,
                max_tokens = 500
            };

            var response = await _httpClient.PostAsJsonAsync(
                "chat/completions",
                requestBody,
                cancellationToken);

            response.EnsureSuccessStatusCode();

            var result = await response.Content.ReadFromJsonAsync<OpenAIResponse>(
                cancellationToken: cancellationToken);

            var assistantMessage = result?.Choices?.FirstOrDefault()?.Message?.Content 
                ?? "Desculpe, não consegui processar sua mensagem.";

            return new AIResponse
            {
                Message = assistantMessage,
                Intent = intent,
                Metadata = new Dictionary<string, string>
                {
                    { "model", _model },
                    { "company_code", companyCode }
                }
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao processar mensagem com OpenAI");
            return new AIResponse
            {
                Message = "Desculpe, ocorreu um erro ao processar sua mensagem. Tente novamente.",
                Intent = ChatIntent.Unknown,
                Metadata = new Dictionary<string, string>()
            };
        }
    }

    public ChatIntent DetectIntent(string message)
    {
        var lowerMessage = message.ToLowerInvariant();

        if (lowerMessage.Contains("meta") && (lowerMessage.Contains("falta") || lowerMessage.Contains("faltam")))
            return ChatIntent.GoalGap;

        if (lowerMessage.Contains("dica") || lowerMessage.Contains("como vender"))
            return ChatIntent.Tips;

        if (lowerMessage.Contains("ranking") || lowerMessage.Contains("top"))
            return ChatIntent.Ranking;

        if (lowerMessage.Contains("como está") && !lowerMessage.Contains("equipe"))
            return ChatIntent.SellerPerformance;

        if (lowerMessage.Contains("motivação") || lowerMessage.Contains("motivacional"))
            return ChatIntent.TeamMotivation;

        if (lowerMessage.Contains("produto") || lowerMessage.Contains("categoria"))
            return ChatIntent.ProductHelp;

        return ChatIntent.GeneralQuestion;
    }

    private string BuildSystemPrompt(ChatIntent intent, Dictionary<string, object>? context)
    {
        var basePrompt = @"Você é a LIA, uma assistente virtual especializada em vendas de cosméticos. 
Seu objetivo é ajudar vendedores e gerentes a atingir suas metas através de insights, 
dicas práticas e motivação. Seja objetiva, positiva e empática.";

        return intent switch
        {
            ChatIntent.GoalGap => basePrompt + @"
O usuário está perguntando sobre o gap para a meta. 
Use os dados fornecidos para calcular quanto falta e dê insights sobre como alcançar.",

            ChatIntent.Tips => basePrompt + @"
O usuário precisa de dicas de abordagem de vendas. 
Forneça técnicas consultivas, focadas em benefícios e experiência do cliente.",

            ChatIntent.Ranking => basePrompt + @"
O usuário quer ver o ranking de vendas. 
Apresente os dados de forma motivacional, celebrando os destaques.",

            ChatIntent.TeamMotivation => basePrompt + @"
Crie uma mensagem motivacional curta e impactante para a equipe.",

            _ => basePrompt
        };
    }

    private class OpenAIResponse
    {
        [JsonPropertyName("choices")]
        public List<Choice>? Choices { get; set; }
    }

    private class Choice
    {
        [JsonPropertyName("message")]
        public Message? Message { get; set; }
    }

    private class Message
    {
        [JsonPropertyName("content")]
        public string? Content { get; set; }
    }
}
```

---

### 2.4 API Layer

#### `src/LiaXP.Api/Controllers/ChatController.cs`
```csharp
using LiaXP.Application.DTOs.Chat;
using LiaXP.Application.UseCases.Chat;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace LiaXP.Api.Controllers;

[Authorize]
[ApiController]
[Route("chat")]
[Produces("application/json")]
public class ChatController : ControllerBase
{
    private readonly IProcessChatUseCase _processChatUseCase;
    private readonly ILogger<ChatController> _logger;

    public ChatController(
        IProcessChatUseCase processChatUseCase,
        ILogger<ChatController> logger)
    {
        _processChatUseCase = processChatUseCase;
        _logger = logger;
    }

    /// <summary>
    /// Processa uma mensagem de chat com a IA
    /// </summary>
    /// <param name="request">Mensagem do usuário</param>
    /// <param name="cancellationToken">Token de cancelamento</param>
    /// <returns>Resposta da IA</returns>
    /// <response code="200">Mensagem processada com sucesso</response>
    /// <response code="400">Requisição inválida</response>
    /// <response code="401">Não autenticado</response>
    [HttpPost]
    [ProducesResponseType(typeof(ChatResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Chat(
        [FromBody] ChatRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetUserId();
        var companyCode = GetCompanyCode();

        var result = await _processChatUseCase.ExecuteAsync(
            request,
            userId,
            companyCode,
            cancellationToken);

        if (!result.IsSuccess)
        {
            return BadRequest(new ProblemDetails
            {
                Status = StatusCodes.Status400BadRequest,
                Title = "Erro ao processar chat",
                Detail = result.ErrorMessage
            });
        }

        return Ok(result.Data);
    }

    private Guid GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        return Guid.Parse(userIdClaim ?? throw new UnauthorizedAccessException());
    }

    private string GetCompanyCode()
    {
        return User.FindFirst("company_code")?.Value 
            ?? throw new UnauthorizedAccessException("Company code não encontrado");
    }
}
```

---

## 📊 3. Endpoint de Importação de Dados (/data/import/xlsx)

### 3.1 Domain Layer

#### `src/LiaXP.Domain/Entities/SalesData.cs`
```csharp
namespace LiaXP.Domain.Entities;

public class SalesData
{
    public Guid Id { get; private set; }
    public string CompanyCode { get; private set; }
    public DateTime Date { get; private set; }
    public string Store { get; private set; }
    public string SellerCode { get; private set; }
    public string SellerName { get; private set; }
    public decimal TotalValue { get; private set; }
    public int ItemsQty { get; private set; }
    public decimal AvgTicket { get; private set; }
    public string Category { get; private set; }
    public DateTime ImportedAt { get; private set; }

    private SalesData() { }

    public SalesData(
        string companyCode,
        DateTime date,
        string store,
        string sellerCode,
        string sellerName,
        decimal totalValue,
        int itemsQty,
        decimal avgTicket,
        string category)
    {
        Id = Guid.NewGuid();
        CompanyCode = companyCode;
        Date = date;
        Store = store;
        SellerCode = sellerCode;
        SellerName = sellerName;
        TotalValue = totalValue;
        ItemsQty = itemsQty;
        AvgTicket = avgTicket;
        Category = category;
        ImportedAt = DateTime.UtcNow;
    }
}

public class GoalData
{
    public Guid Id { get; private set; }
    public string CompanyCode { get; private set; }
    public string Month { get; private set; }
    public string Store { get; private set; }
    public string SellerCode { get; private set; }
    public decimal TargetValue { get; private set; }
    public decimal TargetTicket { get; private set; }
    public string TargetConversion { get; private set; }
    public DateTime ImportedAt { get; private set; }

    private GoalData() { }

    public GoalData(
        string companyCode,
        string month,
        string store,
        string sellerCode,
        decimal targetValue,
        decimal targetTicket,
        string targetConversion)
    {
        Id = Guid.NewGuid();
        CompanyCode = companyCode;
        Month = month;
        Store = store;
        SellerCode = sellerCode;
        TargetValue = targetValue;
        TargetTicket = targetTicket;
        TargetConversion = targetConversion;
        ImportedAt = DateTime.UtcNow;
    }
}

public class TeamMember
{
    public Guid Id { get; private set; }
    public string CompanyCode { get; private set; }
    public string SellerCode { get; private set; }
    public string SellerName { get; private set; }
    public string Role { get; private set; }
    public string Store { get; private set; }
    public string PhoneE164 { get; private set; }
    public string Status { get; private set; }
    public DateTime ImportedAt { get; private set; }

    private TeamMember() { }

    public TeamMember(
        string companyCode,
        string sellerCode,
        string sellerName,
        string role,
        string store,
        string phoneE164,
        string status = "active")
    {
        Id = Guid.NewGuid();
        CompanyCode = companyCode;
        SellerCode = sellerCode;
        SellerName = sellerName;
        Role = role;
        Store = store;
        PhoneE164 = phoneE164;
        Status = status;
        ImportedAt = DateTime.UtcNow;
    }
}
```

#### `src/LiaXP.Domain/Interfaces/IExcelImportService.cs`
```csharp
namespace LiaXP.Domain.Interfaces;

public interface IExcelImportService
{
    Task<ImportResult> ImportAsync(
        Stream fileStream,
        string companyCode,
        CancellationToken cancellationToken = default);
}

public class ImportResult
{
    public bool Success { get; set; }
    public int SalesCount { get; set; }
    public int GoalsCount { get; set; }
    public int TeamCount { get; set; }
    public List<string> Errors { get; set; } = new();
    public string? Message { get; set; }
}
```

---

### 3.2 Application Layer

#### `src/LiaXP.Application/UseCases/Data/ImportExcelUseCase.cs`
```csharp
using LiaXP.Domain.Interfaces;
using Microsoft.Extensions.Logging;

namespace LiaXP.Application.UseCases.Data;

public interface IImportExcelUseCase
{
    Task<Result<ImportResult>> ExecuteAsync(
        Stream fileStream,
        string companyCode,
        bool retrain = false,
        CancellationToken cancellationToken = default);
}

public class ImportExcelUseCase : IImportExcelUseCase
{
    private readonly IExcelImportService _importService;
    private readonly ILogger<ImportExcelUseCase> _logger;

    public ImportExcelUseCase(
        IExcelImportService importService,
        ILogger<ImportExcelUseCase> logger)
    {
        _importService = importService;
        _logger = logger;
    }

    public async Task<Result<ImportResult>> ExecuteAsync(
        Stream fileStream,
        string companyCode,
        bool retrain = false,
        CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Iniciando importação de dados para company: {CompanyCode}", companyCode);

            var result = await _importService.ImportAsync(fileStream, companyCode, cancellationToken);

            if (result.Success)
            {
                _logger.LogInformation(
                    "Importação concluída. Vendas: {Sales}, Metas: {Goals}, Equipe: {Team}",
                    result.SalesCount,
                    result.GoalsCount,
                    result.TeamCount);

                // Se retrain=true, disparar retreinamento de insights aqui
                if (retrain)
                {
                    _logger.LogInformation("Retreinamento solicitado após importação");
                    // TODO: Implementar retreinamento
                }
            }

            return Result<ImportResult>.Success(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao importar dados para company: {CompanyCode}", companyCode);
            return Result<ImportResult>.Failure("Erro ao importar dados");
        }
    }
}
```

---

### 3.3 Infrastructure Layer

#### `src/LiaXP.Infrastructure/Services/ExcelImportService.cs`
```csharp
using ClosedXML.Excel;
using Dapper;
using LiaXP.Domain.Entities;
using LiaXP.Domain.Interfaces;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LiaXP.Infrastructure.Services;

public class ExcelImportService : IExcelImportService
{
    private readonly string _connectionString;
    private readonly ILogger<ExcelImportService> _logger;

    public ExcelImportService(IConfiguration configuration, ILogger<ExcelImportService> logger)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("Connection string not found");
        _logger = logger;
    }

    public async Task<ImportResult> ImportAsync(
        Stream fileStream,
        string companyCode,
        CancellationToken cancellationToken = default)
    {
        var result = new ImportResult { Success = false };

        try
        {
            using var workbook = new XLWorkbook(fileStream);

            // Importar vendas
            if (workbook.TryGetWorksheet("Vendas", out var salesSheet))
            {
                result.SalesCount = await ImportSalesAsync(salesSheet, companyCode, cancellationToken);
            }

            // Importar metas
            if (workbook.TryGetWorksheet("Metas", out var goalsSheet))
            {
                result.GoalsCount = await ImportGoalsAsync(goalsSheet, companyCode, cancellationToken);
            }

            // Importar equipe
            if (workbook.TryGetWorksheet("Equipe", out var teamSheet))
            {
                result.TeamCount = await ImportTeamAsync(teamSheet, companyCode, cancellationToken);
            }

            result.Success = true;
            result.Message = "Importação concluída com sucesso";
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro durante importação");
            result.Errors.Add(ex.Message);
            result.Message = "Erro durante importação";
        }

        return result;
    }

    private async Task<int> ImportSalesAsync(
        IXLWorksheet sheet,
        string companyCode,
        CancellationToken cancellationToken)
    {
        var rows = sheet.RowsUsed().Skip(1); // Pular cabeçalho
        var salesData = new List<SalesData>();

        foreach (var row in rows)
        {
            try
            {
                var sale = new SalesData(
                    companyCode,
                    row.Cell(1).GetValue<DateTime>(),  // data
                    row.Cell(2).GetValue<string>(),    // loja
                    row.Cell(3).GetValue<string>(),    // vendedora (código)
                    row.Cell(3).GetValue<string>(),    // vendedora (nome)
                    row.Cell(4).GetValue<decimal>(),   // valor_total
                    row.Cell(5).GetValue<int>(),       // qtd_itens
                    row.Cell(6).GetValue<decimal>(),   // ticket_medio
                    row.Cell(7).GetValue<string>()     // categoria
                );

                salesData.Add(sale);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Erro ao processar linha {Row} da planilha Vendas", row.RowNumber());
            }
        }

        // Bulk insert
        using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);

        const string sql = @"
            INSERT INTO SalesData (Id, CompanyCode, Date, Store, SellerCode, SellerName, 
                                    TotalValue, ItemsQty, AvgTicket, Category, ImportedAt)
            VALUES (@Id, @CompanyCode, @Date, @Store, @SellerCode, @SellerName, 
                    @TotalValue, @ItemsQty, @AvgTicket, @Category, @ImportedAt)";

        foreach (var sale in salesData)
        {
            await connection.ExecuteAsync(
                new CommandDefinition(sql, new
                {
                    sale.Id,
                    sale.CompanyCode,
                    sale.Date,
                    sale.Store,
                    sale.SellerCode,
                    sale.SellerName,
                    sale.TotalValue,
                    sale.ItemsQty,
                    sale.AvgTicket,
                    sale.Category,
                    sale.ImportedAt
                }, cancellationToken: cancellationToken));
        }

        return salesData.Count;
    }

    private async Task<int> ImportGoalsAsync(
        IXLWorksheet sheet,
        string companyCode,
        CancellationToken cancellationToken)
    {
        // Implementação similar ao ImportSalesAsync
        // ...
        return 0;
    }

    private async Task<int> ImportTeamAsync(
        IXLWorksheet sheet,
        string companyCode,
        CancellationToken cancellationToken)
    {
        // Implementação similar ao ImportSalesAsync
        // ...
        return 0;
    }
}
```

---

### 3.4 API Layer

#### `src/LiaXP.Api/Controllers/DataController.cs`
```csharp
using LiaXP.Application.UseCases.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace LiaXP.Api.Controllers;

[Authorize(Roles = "Admin,Manager")]
[ApiController]
[Route("data")]
[Produces("application/json")]
public class DataController : ControllerBase
{
    private readonly IImportExcelUseCase _importExcelUseCase;
    private readonly ILogger<DataController> _logger;

    public DataController(
        IImportExcelUseCase importExcelUseCase,
        ILogger<DataController> logger)
    {
        _importExcelUseCase = importExcelUseCase;
        _logger = logger;
    }

    /// <summary>
    /// Importa dados de vendas, metas e equipe a partir de arquivo Excel
    /// </summary>
    /// <param name="file">Arquivo Excel (.xlsx)</param>
    /// <param name="retrain">Se deve retreinar insights após importação</param>
    /// <param name="cancellationToken">Token de cancelamento</param>
    /// <returns>Resultado da importação</returns>
    /// <response code="200">Importação realizada com sucesso</response>
    /// <response code="400">Arquivo inválido</response>
    /// <response code="401">Não autenticado</response>
    /// <response code="403">Sem permissão (requer Admin ou Manager)</response>
    [HttpPost("import/xlsx")]
    [ProducesResponseType(typeof(ImportResult), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [Consumes("multipart/form-data")]
    public async Task<IActionResult> ImportExcel(
        IFormFile file,
        [FromQuery] bool retrain = false,
        CancellationToken cancellationToken = default)
    {
        if (file == null || file.Length == 0)
        {
            return BadRequest(new ProblemDetails
            {
                Status = StatusCodes.Status400BadRequest,
                Title = "Arquivo inválido",
                Detail = "Nenhum arquivo foi enviado"
            });
        }

        if (!file.FileName.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase))
        {
            return BadRequest(new ProblemDetails
            {
                Status = StatusCodes.Status400BadRequest,
                Title = "Formato inválido",
                Detail = "Apenas arquivos .xlsx são suportados"
            });
        }

        var companyCode = User.FindFirst("company_code")?.Value
            ?? throw new UnauthorizedAccessException("Company code não encontrado");

        using var stream = file.OpenReadStream();
        var result = await _importExcelUseCase.ExecuteAsync(stream, companyCode, retrain, cancellationToken);

        if (!result.IsSuccess)
        {
            return BadRequest(new ProblemDetails
            {
                Status = StatusCodes.Status400BadRequest,
                Title = "Erro na importação",
                Detail = result.ErrorMessage
            });
        }

        return Ok(result.Data);
    }

    /// <summary>
    /// Obtém o status da última importação
    /// </summary>
    /// <returns>Status da importação</returns>
    [HttpGet("status")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult GetStatus()
    {
        // TODO: Implementar busca de status da última importação
        return Ok(new
        {
            LastImport = DateTime.UtcNow.AddHours(-2),
            Status = "completed",
            RecordsProcessed = 150
        });
    }
}
```

---

## 📱 4. Endpoint de Webhook WhatsApp (/webhook/whatsapp)

### 4.1 Application Layer

#### `src/LiaXP.Application/DTOs/Webhook/WhatsAppWebhookRequest.cs`
```csharp
using System.Text.Json.Serialization;

namespace LiaXP.Application.DTOs.Webhook;

public record WhatsAppWebhookRequest
{
    [JsonPropertyName("object")]
    public string Object { get; init; } = string.Empty;

    [JsonPropertyName("entry")]
    public List<WebhookEntry> Entry { get; init; } = new();
}

public record WebhookEntry
{
    [JsonPropertyName("id")]
    public string Id { get; init; } = string.Empty;

    [JsonPropertyName("changes")]
    public List<WebhookChange> Changes { get; init; } = new();
}

public record WebhookChange
{
    [JsonPropertyName("value")]
    public WebhookValue Value { get; init; } = new();

    [JsonPropertyName("field")]
    public string Field { get; init; } = string.Empty;
}

public record WebhookValue
{
    [JsonPropertyName("messaging_product")]
    public string MessagingProduct { get; init; } = string.Empty;

    [JsonPropertyName("metadata")]
    public WebhookMetadata Metadata { get; init; } = new();

    [JsonPropertyName("contacts")]
    public List<WebhookContact> Contacts { get; init; } = new();

    [JsonPropertyName("messages")]
    public List<WebhookMessage> Messages { get; init; } = new();
}

public record WebhookMetadata
{
    [JsonPropertyName("display_phone_number")]
    public string DisplayPhoneNumber { get; init; } = string.Empty;

    [JsonPropertyName("phone_number_id")]
    public string PhoneNumberId { get; init; } = string.Empty;
}

public record WebhookContact
{
    [JsonPropertyName("profile")]
    public WebhookProfile Profile { get; init; } = new();

    [JsonPropertyName("wa_id")]
    public string WaId { get; init; } = string.Empty;
}

public record WebhookProfile
{
    [JsonPropertyName("name")]
    public string Name { get; init; } = string.Empty;
}

public record WebhookMessage
{
    [JsonPropertyName("from")]
    public string From { get; init; } = string.Empty;

    [JsonPropertyName("id")]
    public string Id { get; init; } = string.Empty;

    [JsonPropertyName("timestamp")]
    public string Timestamp { get; init; } = string.Empty;

    [JsonPropertyName("text")]
    public WebhookText Text { get; init; } = new();

    [JsonPropertyName("type")]
    public string Type { get; init; } = string.Empty;
}

public record WebhookText
{
    [JsonPropertyName("body")]
    public string Body { get; init; } = string.Empty;
}
```

---

### 4.2 API Layer

#### `src/LiaXP.Api/Controllers/WebhookController.cs`
```csharp
using LiaXP.Application.DTOs.Webhook;
using Microsoft.AspNetCore.Mvc;

namespace LiaXP.Api.Controllers;

[ApiController]
[Route("webhook")]
[Produces("application/json")]
public class WebhookController : ControllerBase
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<WebhookController> _logger;

    public WebhookController(IConfiguration configuration, ILogger<WebhookController> logger)
    {
        _configuration = configuration;
        _logger = logger;
    }

    /// <summary>
    /// Verificação do webhook do WhatsApp (Meta)
    /// </summary>
    [HttpGet("whatsapp")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public IActionResult VerifyWebhook(
        [FromQuery(Name = "hub.mode")] string mode,
        [FromQuery(Name = "hub.challenge")] string challenge,
        [FromQuery(Name = "hub.verify_token")] string verifyToken)
    {
        var expectedToken = _configuration["WhatsApp:VerifyToken"];

        if (mode == "subscribe" && verifyToken == expectedToken)
        {
            _logger.LogInformation("Webhook verificado com sucesso");
            return Ok(challenge);
        }

        _logger.LogWarning("Falha na verificação do webhook");
        return StatusCode(StatusCodes.Status403Forbidden);
    }

    /// <summary>
    /// Recebe mensagens do WhatsApp
    /// </summary>
    [HttpPost("whatsapp")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> ReceiveMessage([FromBody] WhatsAppWebhookRequest request)
    {
        try
        {
            _logger.LogInformation("Webhook recebido: {Object}", request.Object);

            foreach (var entry in request.Entry)
            {
                foreach (var change in entry.Changes)
                {
                    if (change.Field == "messages")
                    {
                        foreach (var message in change.Value.Messages)
                        {
                            _logger.LogInformation(
                                "Mensagem recebida de {From}: {Text}",
                                message.From,
                                message.Text.Body);

                            // TODO: Processar mensagem (identificar vendedor, processar com IA, responder)
                        }
                    }
                }
            }

            return Ok(new { status = "success" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao processar webhook do WhatsApp");
            return Ok(new { status = "error" }); // Retornar 200 para não retentar
        }
    }
}
```

---

## ⏰ 5. Endpoint de Cron Manual (/cron/run-now)

#### `src/LiaXP.Api/Controllers/CronController.cs`
```csharp
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LiaXP.Api.Controllers;

[Authorize(Roles = "Admin,Manager")]
[ApiController]
[Route("cron")]
[Produces("application/json")]
public class CronController : ControllerBase
{
    private readonly ILogger<CronController> _logger;

    public CronController(ILogger<CronController> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Executa manualmente a geração de mensagens agendadas
    /// </summary>
    /// <param name="moment">Momento do dia (morning, midday, evening)</param>
    /// <param name="send">Se deve enviar as mensagens ou apenas gerar para revisão</param>
    /// <returns>Resultado da execução</returns>
    [HttpPost("run-now")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> RunNow(
        [FromQuery] string moment = "morning",
        [FromQuery] bool send = false)
    {
        try
        {
            _logger.LogInformation("Execução manual de cron iniciada: {Moment}, Send: {Send}", moment, send);

            // TODO: Implementar lógica de geração e envio de mensagens

            return Ok(new
            {
                Status = "success",
                Moment = moment,
                MessagesSent = send ? 5 : 0,
                MessagesGenerated = 5
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao executar cron manual");
            return StatusCode(500, new { error = "Erro ao executar cron" });
        }
    }
}
```

---

## 📋 Próximos Passos

1. **Configurar o banco de dados**
   ```bash
   # Execute os scripts SQL na ordem:
   01-create-users-table.sql
   02-create-sales-tables.sql
   03-create-chat-tables.sql
   04-create-reviews-tables.sql
   ```

2. **Instalar pacotes NuGet necessários**
   ```bash
   dotnet add package Microsoft.AspNetCore.Authentication.JwtBearer
   dotnet add package Dapper
   dotnet add package ClosedXML
   dotnet add package System.IdentityModel.Tokens.Jwt
   ```

3. **Testar autenticação**
   ```bash
   curl -X POST "https://localhost:5001/auth/token" \
     -H "Content-Type: application/json" \
     -d '{"email":"admin@liaxp.com","password":"Admin@123","companyCode":"DEMO"}'
   ```

4. **Implementar endpoints restantes**
   - /insights
   - /reviews/{id}/approve
   - /reviews/{id}/edit-and-approve
   - /train

---

## 📚 Recursos Adicionais

- [Clean Architecture by Uncle Bob](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html)
- [Domain-Driven Design](https://martinfowler.com/bliki/DomainDrivenDesign.html)
- [Hexagonal Architecture](https://alistair.cockburn.us/hexagonal-architecture/)
