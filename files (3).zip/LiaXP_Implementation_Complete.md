# LiaXP - Implementação Completa dos Endpoints

## 📋 Visão Geral

Este documento fornece a implementação completa de todos os endpoints necessários para o sistema LiaXP, seguindo as melhores práticas de:
- **Domain-Driven Design (DDD)**
- **Clean Code**
- **Arquitetura Hexagonal (Ports & Adapters)**
- **SOLID Principles**

---

## 🏗️ Estrutura de Camadas

```
LiaXP/
├── src/
│   ├── LiaXP.Domain/           # Camada de Domínio (Core)
│   │   ├── Entities/           # Entidades de domínio
│   │   ├── ValueObjects/       # Objetos de valor
│   │   ├── Interfaces/         # Portas (Interfaces)
│   │   └── Exceptions/         # Exceções de domínio
│   │
│   ├── LiaXP.Application/      # Camada de Aplicação (Use Cases)
│   │   ├── UseCases/           # Casos de uso
│   │   ├── DTOs/               # Data Transfer Objects
│   │   ├── Interfaces/         # Interfaces de serviços
│   │   └── Validators/         # Validadores
│   │
│   ├── LiaXP.Infrastructure/   # Camada de Infraestrutura (Adapters)
│   │   ├── Data/               # Repositórios
│   │   ├── Services/           # Serviços externos
│   │   └── Messaging/          # WhatsApp, Email, etc.
│   │
│   └── LiaXP.Api/              # Camada de Apresentação (API)
│       ├── Controllers/        # Controllers REST
│       ├── Middleware/         # Middleware customizado
│       └── Filters/            # Filtros de ação
```

---

## 🔐 1. Endpoint de Autenticação (/auth/token)

### 1.1 Domain Layer

#### `src/LiaXP.Domain/Entities/User.cs`
```csharp
namespace LiaXP.Domain.Entities;

public class User
{
    public Guid Id { get; private set; }
    public string CompanyCode { get; private set; }
    public string Email { get; private set; }
    public string PasswordHash { get; private set; }
    public string FullName { get; private set; }
    public UserRole Role { get; private set; }
    public bool IsActive { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime? LastLoginAt { get; private set; }

    private User() { } // EF Core

    public User(
        string companyCode,
        string email,
        string passwordHash,
        string fullName,
        UserRole role)
    {
        Id = Guid.NewGuid();
        CompanyCode = companyCode ?? throw new ArgumentNullException(nameof(companyCode));
        Email = email?.ToLowerInvariant() ?? throw new ArgumentNullException(nameof(email));
        PasswordHash = passwordHash ?? throw new ArgumentNullException(nameof(passwordHash));
        FullName = fullName ?? throw new ArgumentNullException(nameof(fullName));
        Role = role;
        IsActive = true;
        CreatedAt = DateTime.UtcNow;
    }

    public void UpdateLastLogin()
    {
        LastLoginAt = DateTime.UtcNow;
    }

    public void Deactivate()
    {
        IsActive = false;
    }
}

public enum UserRole
{
    Admin = 1,
    Manager = 2,
    Seller = 3
}
```

#### `src/LiaXP.Domain/Interfaces/IUserRepository.cs`
```csharp
namespace LiaXP.Domain.Interfaces;

public interface IUserRepository
{
    Task<User?> GetByEmailAsync(string email, string companyCode, CancellationToken cancellationToken = default);
    Task<User?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task<User> CreateAsync(User user, CancellationToken cancellationToken = default);
    Task UpdateAsync(User user, CancellationToken cancellationToken = default);
}
```

#### `src/LiaXP.Domain/Interfaces/IPasswordHasher.cs`
```csharp
namespace LiaXP.Domain.Interfaces;

public interface IPasswordHasher
{
    string HashPassword(string password);
    bool VerifyPassword(string password, string passwordHash);
}
```

#### `src/LiaXP.Domain/Interfaces/ITokenService.cs`
```csharp
namespace LiaXP.Domain.Interfaces;

public interface ITokenService
{
    string GenerateToken(User user);
    TokenValidationResult ValidateToken(string token);
}

public class TokenValidationResult
{
    public bool IsValid { get; set; }
    public Guid? UserId { get; set; }
    public string? CompanyCode { get; set; }
    public string? Role { get; set; }
    public string? ErrorMessage { get; set; }
}
```

---

### 1.2 Application Layer

#### `src/LiaXP.Application/DTOs/Auth/LoginRequest.cs`
```csharp
namespace LiaXP.Application.DTOs.Auth;

public record LoginRequest
{
    public string Email { get; init; } = string.Empty;
    public string Password { get; init; } = string.Empty;
    public string CompanyCode { get; init; } = string.Empty;
}
```

#### `src/LiaXP.Application/DTOs/Auth/LoginResponse.cs`
```csharp
namespace LiaXP.Application.DTOs.Auth;

public record LoginResponse
{
    public string AccessToken { get; init; } = string.Empty;
    public string TokenType { get; init; } = "Bearer";
    public int ExpiresIn { get; init; } = 3600;
    public UserInfo User { get; init; } = default!;
}

public record UserInfo
{
    public Guid Id { get; init; }
    public string Email { get; init; } = string.Empty;
    public string FullName { get; init; } = string.Empty;
    public string Role { get; init; } = string.Empty;
    public string CompanyCode { get; init; } = string.Empty;
}
```

#### `src/LiaXP.Application/UseCases/Auth/LoginUseCase.cs`
```csharp
using LiaXP.Application.DTOs.Auth;
using LiaXP.Domain.Interfaces;
using Microsoft.Extensions.Logging;

namespace LiaXP.Application.UseCases.Auth;

public interface ILoginUseCase
{
    Task<Result<LoginResponse>> ExecuteAsync(LoginRequest request, CancellationToken cancellationToken = default);
}

public class LoginUseCase : ILoginUseCase
{
    private readonly IUserRepository _userRepository;
    private readonly IPasswordHasher _passwordHasher;
    private readonly ITokenService _tokenService;
    private readonly ILogger<LoginUseCase> _logger;

    public LoginUseCase(
        IUserRepository userRepository,
        IPasswordHasher passwordHasher,
        ITokenService tokenService,
        ILogger<LoginUseCase> logger)
    {
        _userRepository = userRepository;
        _passwordHasher = passwordHasher;
        _tokenService = tokenService;
        _logger = logger;
    }

    public async Task<Result<LoginResponse>> ExecuteAsync(
        LoginRequest request, 
        CancellationToken cancellationToken = default)
    {
        try
        {
            // Validar entrada
            if (string.IsNullOrWhiteSpace(request.Email) || 
                string.IsNullOrWhiteSpace(request.Password) ||
                string.IsNullOrWhiteSpace(request.CompanyCode))
            {
                return Result<LoginResponse>.Failure("Email, senha e código da empresa são obrigatórios");
            }

            // Buscar usuário
            var user = await _userRepository.GetByEmailAsync(
                request.Email.ToLowerInvariant(), 
                request.CompanyCode, 
                cancellationToken);

            if (user == null)
            {
                _logger.LogWarning("Tentativa de login com credenciais inválidas: {Email}", request.Email);
                return Result<LoginResponse>.Failure("Credenciais inválidas");
            }

            // Verificar se está ativo
            if (!user.IsActive)
            {
                _logger.LogWarning("Tentativa de login com usuário inativo: {Email}", request.Email);
                return Result<LoginResponse>.Failure("Usuário inativo");
            }

            // Verificar senha
            if (!_passwordHasher.VerifyPassword(request.Password, user.PasswordHash))
            {
                _logger.LogWarning("Senha incorreta para usuário: {Email}", request.Email);
                return Result<LoginResponse>.Failure("Credenciais inválidas");
            }

            // Atualizar último login
            user.UpdateLastLogin();
            await _userRepository.UpdateAsync(user, cancellationToken);

            // Gerar token
            var token = _tokenService.GenerateToken(user);

            var response = new LoginResponse
            {
                AccessToken = token,
                TokenType = "Bearer",
                ExpiresIn = 3600,
                User = new UserInfo
                {
                    Id = user.Id,
                    Email = user.Email,
                    FullName = user.FullName,
                    Role = user.Role.ToString(),
                    CompanyCode = user.CompanyCode
                }
            };

            _logger.LogInformation("Login bem-sucedido para usuário: {Email}", request.Email);
            return Result<LoginResponse>.Success(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao processar login para {Email}", request.Email);
            return Result<LoginResponse>.Failure("Erro ao processar login");
        }
    }
}

// Helper class para retorno de resultados
public class Result<T>
{
    public bool IsSuccess { get; }
    public T? Data { get; }
    public string? ErrorMessage { get; }

    private Result(bool isSuccess, T? data, string? errorMessage)
    {
        IsSuccess = isSuccess;
        Data = data;
        ErrorMessage = errorMessage;
    }

    public static Result<T> Success(T data) => new(true, data, null);
    public static Result<T> Failure(string errorMessage) => new(false, default, errorMessage);
}
```

---

### 1.3 Infrastructure Layer

#### `src/LiaXP.Infrastructure/Data/Repositories/UserRepository.cs`
```csharp
using Dapper;
using LiaXP.Domain.Entities;
using LiaXP.Domain.Interfaces;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace LiaXP.Infrastructure.Data.Repositories;

public class UserRepository : IUserRepository
{
    private readonly string _connectionString;

    public UserRepository(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection") 
            ?? throw new InvalidOperationException("Connection string not found");
    }

    public async Task<User?> GetByEmailAsync(
        string email, 
        string companyCode, 
        CancellationToken cancellationToken = default)
    {
        using var connection = new SqlConnection(_connectionString);
        
        const string sql = @"
            SELECT 
                Id, CompanyCode, Email, PasswordHash, FullName, 
                Role, IsActive, CreatedAt, LastLoginAt
            FROM Users
            WHERE Email = @Email 
                AND CompanyCode = @CompanyCode 
                AND IsActive = 1";

        var result = await connection.QueryFirstOrDefaultAsync<UserDto>(
            new CommandDefinition(sql, new { Email = email, CompanyCode = companyCode }, cancellationToken: cancellationToken));

        return result?.ToEntity();
    }

    public async Task<User?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        using var connection = new SqlConnection(_connectionString);
        
        const string sql = @"
            SELECT 
                Id, CompanyCode, Email, PasswordHash, FullName, 
                Role, IsActive, CreatedAt, LastLoginAt
            FROM Users
            WHERE Id = @Id";

        var result = await connection.QueryFirstOrDefaultAsync<UserDto>(
            new CommandDefinition(sql, new { Id = id }, cancellationToken: cancellationToken));

        return result?.ToEntity();
    }

    public async Task<User> CreateAsync(User user, CancellationToken cancellationToken = default)
    {
        using var connection = new SqlConnection(_connectionString);
        
        const string sql = @"
            INSERT INTO Users (Id, CompanyCode, Email, PasswordHash, FullName, Role, IsActive, CreatedAt)
            VALUES (@Id, @CompanyCode, @Email, @PasswordHash, @FullName, @Role, @IsActive, @CreatedAt)";

        await connection.ExecuteAsync(
            new CommandDefinition(sql, new
            {
                user.Id,
                user.CompanyCode,
                user.Email,
                user.PasswordHash,
                user.FullName,
                Role = (int)user.Role,
                user.IsActive,
                user.CreatedAt
            }, cancellationToken: cancellationToken));

        return user;
    }

    public async Task UpdateAsync(User user, CancellationToken cancellationToken = default)
    {
        using var connection = new SqlConnection(_connectionString);
        
        const string sql = @"
            UPDATE Users 
            SET LastLoginAt = @LastLoginAt,
                IsActive = @IsActive
            WHERE Id = @Id";

        await connection.ExecuteAsync(
            new CommandDefinition(sql, new
            {
                user.Id,
                user.LastLoginAt,
                user.IsActive
            }, cancellationToken: cancellationToken));
    }

    private class UserDto
    {
        public Guid Id { get; set; }
        public string CompanyCode { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public int Role { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? LastLoginAt { get; set; }

        public User ToEntity()
        {
            // Use reflection para criar instância privada
            var user = (User)Activator.CreateInstance(typeof(User), true)!;
            typeof(User).GetProperty(nameof(Id))!.SetValue(user, Id);
            typeof(User).GetProperty(nameof(CompanyCode))!.SetValue(user, CompanyCode);
            typeof(User).GetProperty(nameof(Email))!.SetValue(user, Email);
            typeof(User).GetProperty(nameof(PasswordHash))!.SetValue(user, PasswordHash);
            typeof(User).GetProperty(nameof(FullName))!.SetValue(user, FullName);
            typeof(User).GetProperty(nameof(Role))!.SetValue(user, (UserRole)Role);
            typeof(User).GetProperty(nameof(IsActive))!.SetValue(user, IsActive);
            typeof(User).GetProperty(nameof(CreatedAt))!.SetValue(user, CreatedAt);
            typeof(User).GetProperty(nameof(LastLoginAt))!.SetValue(user, LastLoginAt);
            return user;
        }
    }
}
```

#### `src/LiaXP.Infrastructure/Services/PasswordHasher.cs`
```csharp
using LiaXP.Domain.Interfaces;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using System.Security.Cryptography;

namespace LiaXP.Infrastructure.Services;

public class PasswordHasher : IPasswordHasher
{
    private const int SaltSize = 16; // 128 bits
    private const int HashSize = 32; // 256 bits
    private const int Iterations = 100000;

    public string HashPassword(string password)
    {
        // Gerar salt
        var salt = RandomNumberGenerator.GetBytes(SaltSize);

        // Hash da senha
        var hash = KeyDerivation.Pbkdf2(
            password: password,
            salt: salt,
            prf: KeyDerivationPrf.HMACSHA256,
            iterationCount: Iterations,
            numBytesRequested: HashSize);

        // Combinar salt + hash
        var hashBytes = new byte[SaltSize + HashSize];
        Array.Copy(salt, 0, hashBytes, 0, SaltSize);
        Array.Copy(hash, 0, hashBytes, SaltSize, HashSize);

        // Retornar como Base64
        return Convert.ToBase64String(hashBytes);
    }

    public bool VerifyPassword(string password, string passwordHash)
    {
        try
        {
            // Extrair salt e hash
            var hashBytes = Convert.FromBase64String(passwordHash);
            var salt = new byte[SaltSize];
            Array.Copy(hashBytes, 0, salt, 0, SaltSize);

            // Hash da senha fornecida
            var hash = KeyDerivation.Pbkdf2(
                password: password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: Iterations,
                numBytesRequested: HashSize);

            // Comparar hashes
            for (int i = 0; i < HashSize; i++)
            {
                if (hashBytes[i + SaltSize] != hash[i])
                    return false;
            }

            return true;
        }
        catch
        {
            return false;
        }
    }
}
```

#### `src/LiaXP.Infrastructure/Services/JwtTokenService.cs`
```csharp
using LiaXP.Domain.Entities;
using LiaXP.Domain.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace LiaXP.Infrastructure.Services;

public class JwtTokenService : ITokenService
{
    private readonly IConfiguration _configuration;
    private readonly string _signingKey;
    private readonly string _issuer;
    private readonly string _audience;

    public JwtTokenService(IConfiguration configuration)
    {
        _configuration = configuration;
        _signingKey = configuration["Jwt:SigningKey"] 
            ?? throw new InvalidOperationException("JWT SigningKey not configured");
        _issuer = configuration["Jwt:Issuer"] ?? "LiaXP";
        _audience = configuration["Jwt:Audience"] ?? "LiaXP-Api";
    }

    public string GenerateToken(User user)
    {
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, user.Email),
            new Claim(JwtRegisteredClaimNames.Name, user.FullName),
            new Claim(ClaimTypes.Role, user.Role.ToString()),
            new Claim("company_code", user.CompanyCode),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new Claim(JwtRegisteredClaimNames.Iat, DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString())
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_signingKey));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: _issuer,
            audience: _audience,
            claims: claims,
            notBefore: DateTime.UtcNow,
            expires: DateTime.UtcNow.AddHours(1),
            signingCredentials: credentials
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    public TokenValidationResult ValidateToken(string token)
    {
        try
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_signingKey);

            var validationParameters = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = true,
                ValidIssuer = _issuer,
                ValidateAudience = true,
                ValidAudience = _audience,
                ValidateLifetime = true,
                ClockSkew = TimeSpan.Zero
            };

            var principal = tokenHandler.ValidateToken(token, validationParameters, out _);

            return new TokenValidationResult
            {
                IsValid = true,
                UserId = Guid.Parse(principal.FindFirst(JwtRegisteredClaimNames.Sub)?.Value ?? string.Empty),
                CompanyCode = principal.FindFirst("company_code")?.Value,
                Role = principal.FindFirst(ClaimTypes.Role)?.Value
            };
        }
        catch (Exception ex)
        {
            return new TokenValidationResult
            {
                IsValid = false,
                ErrorMessage = ex.Message
            };
        }
    }
}
```

---

### 1.4 API Layer

#### `src/LiaXP.Api/Controllers/AuthController.cs`
```csharp
using LiaXP.Application.DTOs.Auth;
using LiaXP.Application.UseCases.Auth;
using Microsoft.AspNetCore.Mvc;

namespace LiaXP.Api.Controllers;

[ApiController]
[Route("auth")]
[Produces("application/json")]
public class AuthController : ControllerBase
{
    private readonly ILoginUseCase _loginUseCase;
    private readonly ILogger<AuthController> _logger;

    public AuthController(ILoginUseCase loginUseCase, ILogger<AuthController> logger)
    {
        _loginUseCase = loginUseCase;
        _logger = logger;
    }

    /// <summary>
    /// Autentica um usuário e retorna um token JWT
    /// </summary>
    /// <param name="request">Credenciais de login</param>
    /// <param name="cancellationToken">Token de cancelamento</param>
    /// <returns>Token de acesso e informações do usuário</returns>
    /// <response code="200">Login realizado com sucesso</response>
    /// <response code="400">Dados inválidos</response>
    /// <response code="401">Credenciais inválidas</response>
    [HttpPost("token")]
    [ProducesResponseType(typeof(LoginResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Login(
        [FromBody] LoginRequest request,
        CancellationToken cancellationToken)
    {
        var result = await _loginUseCase.ExecuteAsync(request, cancellationToken);

        if (!result.IsSuccess)
        {
            return Unauthorized(new ProblemDetails
            {
                Status = StatusCodes.Status401Unauthorized,
                Title = "Autenticação falhou",
                Detail = result.ErrorMessage
            });
        }

        return Ok(result.Data);
    }
}
```

---

### 1.5 Database Schema

#### `scripts/01-create-users-table.sql`
```sql
-- Tabela de usuários
CREATE TABLE Users (
    Id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    CompanyCode NVARCHAR(50) NOT NULL,
    Email NVARCHAR(255) NOT NULL,
    PasswordHash NVARCHAR(500) NOT NULL,
    FullName NVARCHAR(255) NOT NULL,
    Role INT NOT NULL, -- 1=Admin, 2=Manager, 3=Seller
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    LastLoginAt DATETIME2 NULL,
    
    CONSTRAINT UK_Users_Email_Company UNIQUE (Email, CompanyCode),
    INDEX IX_Users_Email_Company (Email, CompanyCode, IsActive)
);

-- Inserir usuário admin padrão (senha: Admin@123)
-- Hash gerado com PasswordHasher
INSERT INTO Users (Id, CompanyCode, Email, PasswordHash, FullName, Role, IsActive, CreatedAt)
VALUES (
    NEWID(),
    'DEMO',
    'admin@liaxp.com',
    'wH9nY8cXxK7fK6jL5mN3pQ==', -- Trocar pelo hash real
    'Administrador',
    1, -- Admin
    1,
    GETUTCDATE()
);
```

---

### 1.6 Configuration

#### `src/LiaXP.Api/appsettings.json`
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=LiaXP;User Id=sa;Password=YourPassword;TrustServerCertificate=True"
  },
  "Jwt": {
    "SigningKey": "your-super-secret-key-min-32-characters-long",
    "Issuer": "LiaXP",
    "Audience": "LiaXP-Api"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
```

#### `src/LiaXP.Api/Program.cs` (Configuração DI)
```csharp
using LiaXP.Application.UseCases.Auth;
using LiaXP.Domain.Interfaces;
using LiaXP.Infrastructure.Data.Repositories;
using LiaXP.Infrastructure.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();

// Swagger/OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "LiaXP API",
        Version = "v1",
        Description = "API para plataforma de inteligência de vendas com IA"
    });

    // Configurar autenticação JWT no Swagger
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "JWT Authorization header usando o esquema Bearer. Exemplo: \"Authorization: Bearer {token}\"",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

// JWT Authentication
var jwtKey = builder.Configuration["Jwt:SigningKey"] 
    ?? throw new InvalidOperationException("JWT SigningKey não configurada");

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
            ClockSkew = TimeSpan.Zero
        };
    });

builder.Services.AddAuthorization();

// Dependency Injection
// Domain Services
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IPasswordHasher, PasswordHasher>();
builder.Services.AddScoped<ITokenService, JwtTokenService>();

// Application Use Cases
builder.Services.AddScoped<ILoginUseCase, LoginUseCase>();

// CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("AllowAll");

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
```

---

## 📝 2. Outros Endpoints Importantes

Agora vou continuar com os demais endpoints...
